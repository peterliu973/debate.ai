"""
SageMaker-compatible HTTP serving entry-point.

Exposes a FastAPI application that:
  POST /invocations          – run the SCOTUS simulation (JSON response)
  POST /invocations/stream   – run with Server-Sent Events streaming
  GET  /ping                 – health check (required by SageMaker)
"""

import json
import logging
import os
import traceback

from fastapi import FastAPI, Request, Response
from fastapi.responses import StreamingResponse
import uvicorn

from src.config import get_config
from src.graph import run_simulation, run_simulation_stream

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("scotus-serve")

app = FastAPI(title="SCOTUS Simulation Endpoint")


@app.get("/ping")
def ping():
    """SageMaker health-check endpoint."""
    return Response(content="", status_code=200)


@app.post("/invocations")
async def invocations(request: Request):
    """
    SageMaker inference endpoint (non-streaming).

    Expected JSON body:
    {
        "case_description": "A state law requires all public-school students to ...",
        "associate_ids": ["sotomayor", "alito"]   // optional
    }

    Returns JSON:
    {
        "opinion": "...",
        "transcript": [...]
    }
    """
    try:
        body = await request.json()
        case_description = body.get("case_description", "")
        associate_ids = body.get("associate_ids", None)

        if not case_description:
            return Response(
                content=json.dumps({"error": "Missing 'case_description' in request body."}),
                status_code=400,
                media_type="application/json",
            )

        logger.info("Starting simulation for case: %s...", case_description[:120])
        config = get_config()
        result = run_simulation(case_description, config, associate_ids)
        logger.info("Simulation complete.")

        return Response(
            content=json.dumps(result, default=str),
            status_code=200,
            media_type="application/json",
        )

    except Exception as e:
        logger.error("Inference error: %s\n%s", e, traceback.format_exc())
        return Response(
            content=json.dumps({"error": str(e)}),
            status_code=500,
            media_type="application/json",
        )


@app.post("/invocations/stream")
async def invocations_stream(request: Request):
    """
    Streaming inference endpoint using Server-Sent Events (SSE).

    Expected JSON body (same as /invocations):
    {
        "case_description": "...",
        "associate_ids": ["sotomayor", "alito"]   // optional
    }

    Returns a stream of SSE events. Each event is a JSON object with an
    "event" key. The last event ("simulation_end") contains the full result.
    """
    try:
        body = await request.json()
        case_description = body.get("case_description", "")
        associate_ids = body.get("associate_ids", None)

        if not case_description:
            return Response(
                content=json.dumps({"error": "Missing 'case_description' in request body."}),
                status_code=400,
                media_type="application/json",
            )

        logger.info("Starting streaming simulation for case: %s...", case_description[:120])
        config = get_config()

        def event_generator():
            try:
                for event in run_simulation_stream(case_description, config, associate_ids):
                    yield f"data: {json.dumps(event, default=str)}\n\n"
                logger.info("Streaming simulation complete.")
            except Exception as exc:
                logger.error("Streaming error: %s\n%s", exc, traceback.format_exc())
                yield f"data: {json.dumps({'event': 'error', 'error': str(exc)})}\n\n"

        return StreamingResponse(event_generator(), media_type="text/event-stream")

    except Exception as e:
        logger.error("Inference error: %s\n%s", e, traceback.format_exc())
        return Response(
            content=json.dumps({"error": str(e)}),
            status_code=500,
            media_type="application/json",
        )


if __name__ == "__main__":
    port = int(os.environ.get("SAGEMAKER_BIND_TO_PORT", "8080"))
    uvicorn.run(app, host="0.0.0.0", port=port)
