"""LLM provider factory.

Supports two back-ends, switchable via ``LLM_PROVIDER``:

* **sagemaker** – calls a SageMaker AI real-time inference endpoint
  (HuggingFace TGI, JumpStart, vLLM, etc.).
* **huggingface** – calls the HuggingFace Inference API *or* loads a
  model locally via ``transformers`` / ``pipeline``.
"""

import json
from typing import Any, Dict, List, Optional

import boto3
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from langchain_core.outputs import ChatGeneration, ChatResult

from src.config import LLMConfig


# ── helpers shared by both providers ────────────────────────────────────────

def _role_str(msg: BaseMessage) -> str:
    if isinstance(msg, SystemMessage):
        return "system"
    if isinstance(msg, HumanMessage):
        return "user"
    return "assistant"


def _parse_hf_response(data) -> str:
    """Parse common HuggingFace / SageMaker TGI response shapes."""
    if isinstance(data, list) and len(data) > 0:
        item = data[0]
        if isinstance(item, dict):
            return item.get("generated_text", str(item))
        return str(item)
    if isinstance(data, dict):
        for key in ("generated_text", "output", "body", "content"):
            if key in data:
                val = data[key]
                return val if isinstance(val, str) else json.dumps(val)
        choices = data.get("choices", [])
        if choices:
            return choices[0].get("message", {}).get("content", str(choices[0]))
    return str(data)


# ═══════════════════════════════════════════════════════════════════════════
# Provider A – SageMaker AI
# ═══════════════════════════════════════════════════════════════════════════

class SageMakerChatLLM(BaseChatModel):
    """
    LangChain ChatModel backed by a SageMaker real-time inference endpoint.
    """

    endpoint_name: str
    region_name: str = "us-east-1"
    content_type: str = "application/json"
    temperature: float = 0.7
    max_tokens: int = 4096

    class Config:
        arbitrary_types_allowed = True

    @property
    def _llm_type(self) -> str:
        return "sagemaker-chat"

    def _get_client(self):
        return boto3.client("sagemaker-runtime", region_name=self.region_name)

    def _build_payload(self, messages: List[BaseMessage]) -> str:
        msgs = [{"role": _role_str(m), "content": m.content} for m in messages]
        return json.dumps({
            "messages": msgs,
            "parameters": {
                "temperature": self.temperature,
                "max_new_tokens": self.max_tokens,
            },
        })

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        **kwargs,
    ) -> ChatResult:
        client = self._get_client()
        response = client.invoke_endpoint(
            EndpointName=self.endpoint_name,
            ContentType=self.content_type,
            Accept="application/json",
            Body=self._build_payload(messages),
        )
        text = _parse_hf_response(json.loads(response["Body"].read()))
        return ChatResult(generations=[ChatGeneration(message=AIMessage(content=text))])


# ═══════════════════════════════════════════════════════════════════════════
# Provider B – HuggingFace (Inference API or local pipeline)
# ═══════════════════════════════════════════════════════════════════════════

class HuggingFaceChatLLM(BaseChatModel):
    """
    LangChain ChatModel that calls the HuggingFace Inference API
    (``huggingface_hub.InferenceClient``) **or** a local ``transformers``
    pipeline when ``run_local=True``.
    """

    model_id: str = "microsoft/Phi-3.5-mini-instruct"
    api_token: str = ""
    temperature: float = 0.7
    max_tokens: int = 4096
    run_local: bool = False
    # Private — populated lazily
    _client: Any = None
    _pipeline: Any = None

    class Config:
        arbitrary_types_allowed = True
        underscore_attrs_are_private = True

    @property
    def _llm_type(self) -> str:
        return "huggingface-chat"

    # ── lazy init ─────────────────────────────────────────────────────

    def _get_hf_client(self):
        if self._client is None:
            from huggingface_hub import InferenceClient
            self._client = InferenceClient(
                model=self.model_id,
                token=self.api_token or None,
            )
        return self._client

    def _get_local_pipeline(self):
        if self._pipeline is None:
            from transformers import pipeline as hf_pipeline
            self._pipeline = hf_pipeline(
                "text-generation",
                model=self.model_id,
                device_map="auto",
                token=self.api_token or None,
            )
        return self._pipeline

    # ── generation ────────────────────────────────────────────────────

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        **kwargs,
    ) -> ChatResult:
        msgs = [{"role": _role_str(m), "content": m.content} for m in messages]

        if self.run_local:
            text = self._generate_local(msgs)
        else:
            text = self._generate_api(msgs)

        return ChatResult(generations=[ChatGeneration(message=AIMessage(content=text))])

    def _generate_api(self, msgs: List[Dict[str, str]]) -> str:
        """Call the HuggingFace Inference API."""
        client = self._get_hf_client()
        response = client.chat_completion(
            messages=msgs,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
        )
        return response.choices[0].message.content

    def _generate_local(self, msgs: List[Dict[str, str]]) -> str:
        """Run the model locally via a transformers pipeline."""
        pipe = self._get_local_pipeline()
        # Build a single prompt from the messages
        prompt_parts = []
        for m in msgs:
            role = m["role"]
            content = m["content"]
            if role == "system":
                prompt_parts.append(f"[INST] <<SYS>>\n{content}\n<</SYS>>")
            elif role == "user":
                prompt_parts.append(f"{content} [/INST]")
            else:
                prompt_parts.append(content)
        prompt = "\n".join(prompt_parts)

        outputs = pipe(
            prompt,
            max_new_tokens=self.max_tokens,
            temperature=self.temperature,
            do_sample=True,
            return_full_text=False,
        )
        return outputs[0]["generated_text"].strip()


# ═══════════════════════════════════════════════════════════════════════════
# Factory
# ═══════════════════════════════════════════════════════════════════════════

def build_llm(config: LLMConfig) -> BaseChatModel:
    """
    Build and return the configured chat model.

    Set ``LLM_PROVIDER=sagemaker`` or ``LLM_PROVIDER=huggingface`` in your
    ``.env`` file to choose the back-end.
    """
    provider = config.provider.lower()

    if provider == "sagemaker":
        return SageMakerChatLLM(
            endpoint_name=config.sagemaker_llm_endpoint,
            region_name="us-east-1",  # overridden in graph.py via AppConfig
            content_type=config.sagemaker_content_type,
            temperature=config.temperature,
            max_tokens=config.max_tokens,
        )

    if provider == "huggingface":
        return HuggingFaceChatLLM(
            model_id=config.hf_llm_model,
            api_token=config.hf_api_token,
            temperature=config.temperature,
            max_tokens=config.max_tokens,
            run_local=config.hf_local,
        )

    raise ValueError(
        f"Unsupported LLM_PROVIDER='{config.provider}'. "
        "Choose 'sagemaker' or 'huggingface'."
    )
