"""
Research tools available to justice agents during oral arguments.

Each tool is a LangChain Tool that the LLM can invoke via tool-calling.
Tools:
  - search_wikipedia   – look up legal concepts, case history, constitutional text
  - search_google_news – search recent news via Google News RSS feed
"""

from __future__ import annotations

import logging
import re
import urllib.parse
from typing import List

import feedparser
import requests
from langchain_core.tools import tool

logger = logging.getLogger(__name__)

# ── Constants ───────────────────────────────────────────────────────────────

_WIKI_API = "https://en.wikipedia.org/w/api.php"
_GOOGLE_NEWS_RSS = "https://news.google.com/rss/search"

_MAX_WIKI_CHARS = 1200  # truncate Wikipedia extracts
_MAX_NEWS_ITEMS = 5


# ── Wikipedia ───────────────────────────────────────────────────────────────

@tool
def search_wikipedia(query: str) -> str:
    """Search Wikipedia for legal concepts, landmark cases, constitutional
    provisions, or historical context.  Returns a concise summary.

    Args:
        query: The search term (e.g. "First Amendment", "Roe v Wade").
    """
    try:
        # Step 1 – search for the best matching article title
        search_resp = requests.get(
            _WIKI_API,
            params={
                "action": "query",
                "list": "search",
                "srsearch": query,
                "srlimit": 3,
                "format": "json",
            },
            timeout=10,
        )
        search_resp.raise_for_status()
        results = search_resp.json().get("query", {}).get("search", [])
        if not results:
            return f"No Wikipedia article found for '{query}'."

        title = results[0]["title"]

        # Step 2 – get the plain-text extract
        extract_resp = requests.get(
            _WIKI_API,
            params={
                "action": "query",
                "titles": title,
                "prop": "extracts",
                "exintro": True,
                "explaintext": True,
                "format": "json",
            },
            timeout=10,
        )
        extract_resp.raise_for_status()
        pages = extract_resp.json().get("query", {}).get("pages", {})
        page = next(iter(pages.values()))
        extract = page.get("extract", "")

        if not extract:
            return f"Wikipedia article '{title}' exists but has no extract."

        # Truncate for context-window friendliness
        if len(extract) > _MAX_WIKI_CHARS:
            extract = extract[:_MAX_WIKI_CHARS].rsplit(" ", 1)[0] + " …"

        return f"**{title}** (Wikipedia)\n\n{extract}"

    except Exception as exc:
        logger.warning("Wikipedia search failed for '%s': %s", query, exc)
        return f"Wikipedia search failed: {exc}"


# ── Google News RSS ─────────────────────────────────────────────────────────

def _strip_html(text: str) -> str:
    """Remove HTML tags from a string."""
    return re.sub(r"<[^>]+>", "", text)


@tool
def search_google_news(query: str) -> str:
    """Search Google News for recent articles related to a legal topic or
    Supreme Court case.  Returns headlines and short descriptions.

    Args:
        query: The search term (e.g. "Supreme Court social media minors").
    """
    try:
        url = f"{_GOOGLE_NEWS_RSS}?q={urllib.parse.quote_plus(query)}&hl=en-US&gl=US&ceid=US:en"
        feed = feedparser.parse(url)

        if not feed.entries:
            return f"No recent news found for '{query}'."

        items: List[str] = []
        for entry in feed.entries[:_MAX_NEWS_ITEMS]:
            title = _strip_html(entry.get("title", ""))
            source = entry.get("source", {}).get("title", "")
            pub_date = entry.get("published", "")
            summary = _strip_html(entry.get("summary", entry.get("description", "")))
            if len(summary) > 300:
                summary = summary[:300].rsplit(" ", 1)[0] + " …"
            item = f"• {title}"
            if source:
                item += f" ({source})"
            if pub_date:
                item += f" — {pub_date}"
            if summary:
                item += f"\n  {summary}"
            items.append(item)

        return "**Google News results:**\n\n" + "\n\n".join(items)

    except Exception as exc:
        logger.warning("Google News search failed for '%s': %s", query, exc)
        return f"Google News search failed: {exc}"


# ── Registry ────────────────────────────────────────────────────────────────

ALL_TOOLS = [search_wikipedia, search_google_news]
"""List of all research tools available to justice agents."""
