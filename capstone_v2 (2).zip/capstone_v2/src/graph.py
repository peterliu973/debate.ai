"""
LangGraph workflow for the SCOTUS Simulation.

Graph topology
==============
                ┌──────────────┐
                │  START        │
                └──────┬───────┘
                       │  case_description
                       ▼
              ┌────────────────┐
              │ chief_open_case│  (frames questions, opens Round 1)
              └───────┬────────┘
                      │
          ┌───────────▼────────────┐
          │  debate_round (loop x3)│
          │  ┌─────────────────┐   │
          │  │ each associate  │   │
          │  │ justice responds│   │
          │  └─────────────────┘   │
          │  chief opens next round│
          └───────────┬────────────┘
                      │  after 3 rounds
                      ▼
             ┌────────────────┐
             │ chief_opinion  │  (final ruling + transcript)
             └───────┬────────┘
                     │
                     ▼
                ┌─────────┐
                │  END    │
                └─────────┘
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Generator, List, Optional, TypedDict

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from langgraph.graph import StateGraph, END

from src.config import AppConfig, get_config
from src.llm import build_llm
from src.tools import ALL_TOOLS
from src.justices import (
    JUSTICE_MAP,
    CHIEF_JUSTICE_ID,
    DEFAULT_ASSOCIATE_IDS,
    JusticeProfile,
)
from src.prompts import (
    CHIEF_JUSTICE_SYSTEM,
    CHIEF_JUSTICE_OPEN_CASE,
    CHIEF_JUSTICE_OPEN_ROUND,
    CHIEF_JUSTICE_FINAL_OPINION,
    ASSOCIATE_JUSTICE_SYSTEM,
    ASSOCIATE_JUSTICE_RESPOND,
)
from src.vectorstore import (
    build_all_vectorstores,
    build_combined_vectorstore,
    get_justice_retriever,
    get_chief_justice_retriever,
)

logger = logging.getLogger(__name__)

# ── Graph state ─────────────────────────────────────────────────────────────

class SCOTUSState(TypedDict):
    """Shared state flowing through the graph."""
    case_description: str
    current_round: int
    total_rounds: int
    # Each entry: {"round": int, "justice_id": str, "text": str}
    transcript: List[Dict[str, Any]]
    # The prompt the Chief Justice poses for the current round
    round_prompt: str
    # Responses collected in the current round (justice_id → text)
    current_round_responses: Dict[str, str]
    # Final opinion text from the Chief Justice
    final_opinion: str
    # Overall result payload
    result: Dict[str, Any]


# ── Helper: retrieve past opinions ─────────────────────────────────────────

def _retrieve_opinions(retriever, query: str, k: int = 5) -> str:
    """Retrieve and format relevant past opinions."""
    if retriever is None:
        return "(No past opinions available — vector store not loaded.)"
    docs = retriever.invoke(query)
    if not docs:
        return "(No relevant past opinions found.)"
    parts = []
    for i, doc in enumerate(docs, 1):
        meta = doc.metadata
        label = meta.get("case_name", meta.get("s3_key", f"doc-{i}"))
        parts.append(f"[{i}] {label}\n{doc.page_content[:600]}")
    return "\n\n".join(parts)


def _transcript_text(transcript: List[Dict[str, Any]]) -> str:
    """Flatten transcript entries into readable text."""
    lines = []
    for entry in transcript:
        role = JUSTICE_MAP[entry["justice_id"]].name if entry["justice_id"] in JUSTICE_MAP else entry["justice_id"]
        lines.append(f"--- {role} (Round {entry['round']}) ---\n{entry['text']}\n")
    return "\n".join(lines)


def _round_summary(transcript: List[Dict[str, Any]], round_num: int) -> str:
    """Summarize a specific round from the transcript."""
    entries = [e for e in transcript if e["round"] == round_num]
    return _transcript_text(entries) if entries else "(No responses yet.)"


# ── Tool-calling helper ────────────────────────────────────────────────────

# Map tool-name → callable so we can dispatch
_TOOL_MAP = {t.name: t for t in ALL_TOOLS}


def _invoke_with_tools(
    llm,
    messages: List,
    tools: List,
    max_tool_calls: int = 3,
    on_tool_call=None,
) -> str:
    """
    Invoke the LLM with tool-calling support.

    Tries ``llm.bind_tools(tools)`` first (works with OpenAI, Anthropic, etc.).
    Falls back to a regex-based tool-call parser for providers that don't
    support native tool calling (e.g. custom HuggingFace endpoints).

    Args:
        llm:             The chat model.
        messages:        Conversation messages ([SystemMessage, HumanMessage, …]).
        tools:           List of LangChain tools to bind.
        max_tool_calls:  Safety cap on how many tool calls to execute.
        on_tool_call:    Optional callback ``(tool_name, tool_input, tool_output) -> None``
                         invoked each time a tool is used (for streaming events).

    Returns:
        The final text content from the LLM after all tool calls are resolved.
    """
    import json as _json
    import re as _re

    # ── Try native bind_tools first ─────────────────────────────────
    try:
        llm_with_tools = llm.bind_tools(tools)
        use_native = True
    except (NotImplementedError, AttributeError, TypeError):
        llm_with_tools = llm
        use_native = False

    conversation = list(messages)
    calls_made = 0

    for _ in range(max_tool_calls + 1):  # +1 for the final text response
        response = llm_with_tools.invoke(conversation)

        # ── Native tool calling ─────────────────────────────────────
        if use_native and hasattr(response, "tool_calls") and response.tool_calls:
            conversation.append(response)  # add the AIMessage with tool_calls
            for tc in response.tool_calls:
                tool_name = tc["name"]
                tool_args = tc["args"]
                tool_fn = _TOOL_MAP.get(tool_name)
                if tool_fn is None:
                    tool_output = f"Unknown tool: {tool_name}"
                else:
                    tool_output = tool_fn.invoke(tool_args)
                calls_made += 1
                if on_tool_call:
                    on_tool_call(tool_name, tool_args, tool_output)
                conversation.append(
                    ToolMessage(content=str(tool_output), tool_call_id=tc["id"])
                )
                if calls_made >= max_tool_calls:
                    break
            continue  # loop back for the LLM to incorporate results

        # ── Fallback: regex tool-call parsing ───────────────────────
        text = response.content if hasattr(response, "content") else str(response)

        # Pattern: <tool_call>search_wikipedia("query")</tool_call> or
        #          TOOL_CALL: search_wikipedia("query")
        tool_pattern = _re.compile(
            r'(?:<tool_call>|TOOL_CALL:\s*)'
            r'(search_wikipedia|search_google_news)'
            r'\(\s*["\']([^"\']+)["\']\s*\)'
            r'(?:</tool_call>)?',
            _re.IGNORECASE,
        )
        matches = tool_pattern.findall(text)

        if matches and calls_made < max_tool_calls:
            tool_results_text = []
            for tool_name, tool_query in matches:
                tool_fn = _TOOL_MAP.get(tool_name.lower())
                if tool_fn is None:
                    tool_out = f"Unknown tool: {tool_name}"
                else:
                    tool_out = tool_fn.invoke({"query": tool_query})
                calls_made += 1
                if on_tool_call:
                    on_tool_call(tool_name, {"query": tool_query}, tool_out)
                tool_results_text.append(
                    f"TOOL RESULT ({tool_name}): {tool_out}"
                )
                if calls_made >= max_tool_calls:
                    break

            # Feed results back and ask for the real response
            conversation.append(AIMessage(content=text))
            conversation.append(
                HumanMessage(content=(
                    "Here are the results from your tool calls:\n\n"
                    + "\n\n".join(tool_results_text)
                    + "\n\nNow provide your substantive response (no more tool calls)."
                ))
            )
            continue  # loop back

        # No tool calls — return the text
        return text

    # Safety: if we exhausted the loop, return whatever we have
    return response.content if hasattr(response, "content") else str(response)


# ── Graph builder ───────────────────────────────────────────────────────────

def build_scotus_graph(
    config: Optional[AppConfig] = None,
    associate_ids: Optional[List[str]] = None,
) -> StateGraph:
    """
    Construct and compile the SCOTUS simulation LangGraph.

    Args:
        config: Optional application config override.
        associate_ids: Which associate justices participate.
                       Defaults to DEFAULT_ASSOCIATE_IDS (Sotomayor & Alito).

    Returns a compiled graph ready for `.invoke()` or `.stream()`.
    """
    if config is None:
        config = get_config()
    if associate_ids is None:
        associate_ids = DEFAULT_ASSOCIATE_IDS

    # IDs needed for vector-store loading
    participating_ids = [CHIEF_JUSTICE_ID] + list(associate_ids)

    llm = build_llm(config.llm)
    if config.llm.provider.lower() == "sagemaker":
        llm.region_name = config.aws.region
    num_rounds = config.simulation.num_debate_rounds
    use_tools = config.simulation.enable_tools
    max_tool_calls = config.simulation.max_tool_calls

    # ── Build vector stores (gracefully degrade if S3 is unavailable) ───
    try:
        justice_stores = build_all_vectorstores(config, participating_ids)
        combined_store = build_combined_vectorstore(config, participating_ids)
    except Exception as e:
        logger.warning("Could not build vector stores from S3: %s. Running without past opinions.", e)
        justice_stores = {}
        combined_store = None

    chief_retriever = get_chief_justice_retriever(combined_store, k=config.simulation.max_opinion_references) if combined_store else None
    justice_retrievers = {
        jid: get_justice_retriever(vs, k=config.simulation.max_opinion_references)
        for jid, vs in justice_stores.items()
    }

    # ── Node functions ──────────────────────────────────────────────────

    def chief_open_case(state: SCOTUSState) -> Dict:
        """Chief Justice frames the case and opens Round 1."""
        profile = JUSTICE_MAP[CHIEF_JUSTICE_ID]
        precedents = _retrieve_opinions(chief_retriever, state["case_description"])

        system_msg = SystemMessage(content=CHIEF_JUSTICE_SYSTEM.format(
            persona_description=profile.persona_description,
            num_rounds=num_rounds,
        ))
        human_msg = HumanMessage(content=CHIEF_JUSTICE_OPEN_CASE.format(
            case_description=state["case_description"],
            precedents=precedents,
        ))

        response = llm.invoke([system_msg, human_msg])
        text = response.content

        return {
            "current_round": 1,
            "total_rounds": num_rounds,
            "round_prompt": text,
            "transcript": [{"round": 0, "justice_id": CHIEF_JUSTICE_ID, "text": text}],
            "current_round_responses": {},
        }

    def associate_justice_debate(state: SCOTUSState) -> Dict:
        """All associate justices respond to the current round prompt."""
        round_num = state["current_round"]
        responses: Dict[str, str] = {}
        new_transcript: List[Dict[str, Any]] = list(state["transcript"])

        for jid in associate_ids:
            profile = JUSTICE_MAP[jid]
            retriever = justice_retrievers.get(jid)
            past_opinions = _retrieve_opinions(retriever, state["case_description"])

            # Collect what other justices already said this round
            other_text = "\n".join(
                f"{JUSTICE_MAP[oid].name}: {otxt}" for oid, otxt in responses.items()
            ) or "(You are the first to respond this round.)"

            system_msg = SystemMessage(content=ASSOCIATE_JUSTICE_SYSTEM.format(
                persona_description=profile.persona_description,
                past_opinions=past_opinions,
            ))
            human_msg = HumanMessage(content=ASSOCIATE_JUSTICE_RESPOND.format(
                round_label=f"Round {round_num}",
                round_prompt=state["round_prompt"],
                other_responses=other_text,
                justice_name=profile.name,
            ))

            if use_tools:
                text = _invoke_with_tools(
                    llm, [system_msg, human_msg], ALL_TOOLS,
                    max_tool_calls=max_tool_calls,
                )
            else:
                result = llm.invoke([system_msg, human_msg])
                text = result.content
            responses[jid] = text
            new_transcript.append({"round": round_num, "justice_id": jid, "text": text})

        return {
            "current_round_responses": responses,
            "transcript": new_transcript,
        }

    def chief_open_next_round(state: SCOTUSState) -> Dict:
        """Chief Justice synthesizes the previous round and opens the next."""
        prev_round = state["current_round"]
        next_round = prev_round + 1
        profile = JUSTICE_MAP[CHIEF_JUSTICE_ID]

        summary = _round_summary(state["transcript"], prev_round)

        system_msg = SystemMessage(content=CHIEF_JUSTICE_SYSTEM.format(
            persona_description=profile.persona_description,
            num_rounds=num_rounds,
        ))
        human_msg = HumanMessage(content=CHIEF_JUSTICE_OPEN_ROUND.format(
            prev_round=prev_round,
            round_summary=summary,
            current_round=next_round,
            total_rounds=num_rounds,
        ))

        result = llm.invoke([system_msg, human_msg])
        text = result.content

        new_transcript = list(state["transcript"])
        new_transcript.append({"round": next_round, "justice_id": CHIEF_JUSTICE_ID, "text": text})

        return {
            "current_round": next_round,
            "round_prompt": text,
            "current_round_responses": {},
            "transcript": new_transcript,
        }

    def chief_final_opinion(state: SCOTUSState) -> Dict:
        """Chief Justice delivers the opinion of the Court."""
        profile = JUSTICE_MAP[CHIEF_JUSTICE_ID]
        full_transcript = _transcript_text(state["transcript"])
        precedents = _retrieve_opinions(chief_retriever, state["case_description"])

        system_msg = SystemMessage(content=CHIEF_JUSTICE_SYSTEM.format(
            persona_description=profile.persona_description,
            num_rounds=num_rounds,
        ))
        human_msg = HumanMessage(content=CHIEF_JUSTICE_FINAL_OPINION.format(
            total_rounds=num_rounds,
            full_transcript=full_transcript,
            precedents=precedents,
        ))

        result = llm.invoke([system_msg, human_msg])
        opinion_text = result.content

        new_transcript = list(state["transcript"])
        new_transcript.append({"round": -1, "justice_id": CHIEF_JUSTICE_ID, "text": opinion_text})

        return {
            "final_opinion": opinion_text,
            "transcript": new_transcript,
            "result": {
                "opinion": opinion_text,
                "transcript": [
                    {
                        "round": e["round"],
                        "justice": JUSTICE_MAP.get(e["justice_id"], JusticeProfile(
                            justice_id=e["justice_id"], name=e["justice_id"],
                            title="", ideology="", persona_description=""
                        )).name,
                        "text": e["text"],
                    }
                    for e in new_transcript
                ],
            },
        }

    # ── Routing logic ───────────────────────────────────────────────────

    def should_continue_debate(state: SCOTUSState) -> str:
        """After associate debate, decide: more rounds or final opinion."""
        if state["current_round"] < state["total_rounds"]:
            return "next_round"
        return "final_opinion"

    # ── Assemble the graph ──────────────────────────────────────────────

    graph = StateGraph(SCOTUSState)

    graph.add_node("chief_open_case", chief_open_case)
    graph.add_node("associate_debate", associate_justice_debate)
    graph.add_node("chief_next_round", chief_open_next_round)
    graph.add_node("chief_final_opinion", chief_final_opinion)

    graph.set_entry_point("chief_open_case")
    graph.add_edge("chief_open_case", "associate_debate")
    graph.add_conditional_edges(
        "associate_debate",
        should_continue_debate,
        {
            "next_round": "chief_next_round",
            "final_opinion": "chief_final_opinion",
        },
    )
    graph.add_edge("chief_next_round", "associate_debate")
    graph.add_edge("chief_final_opinion", END)

    return graph.compile()


# ── Public entry point ──────────────────────────────────────────────────────

def run_simulation(
    case_description: str,
    config: Optional[AppConfig] = None,
    associate_ids: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Run the full SCOTUS simulation end-to-end (non-streaming).

    Args:
        case_description: Plain-text description of the case from the user.
        config: Optional override config.
        associate_ids: Which associate justices participate.
                       Defaults to DEFAULT_ASSOCIATE_IDS (Sotomayor & Alito).

    Returns:
        Dict with keys "opinion" and "transcript".
    """
    if config is None:
        config = get_config()

    graph = build_scotus_graph(config, associate_ids)

    initial_state: SCOTUSState = {
        "case_description": case_description,
        "current_round": 0,
        "total_rounds": config.simulation.num_debate_rounds,
        "transcript": [],
        "round_prompt": "",
        "current_round_responses": {},
        "final_opinion": "",
        "result": {},
    }

    final_state = graph.invoke(initial_state)
    return final_state["result"]


def run_simulation_stream(
    case_description: str,
    config: Optional[AppConfig] = None,
    associate_ids: Optional[List[str]] = None,
) -> Generator[Dict[str, Any], None, None]:
    """
    Run the SCOTUS simulation and **stream** intermediate events.

    Yields dicts of the form::

        {"event": "<event_type>", ...payload}

    Event types
    -----------
    - ``simulation_start``  – emitted once at the beginning.
    - ``chief_open_case``   – Chief Justice frames the case.
    - ``justice_response``  – each associate justice response (per-round).
    - ``chief_next_round``  – Chief Justice opens a new round.
    - ``chief_opinion``     – final opinion of the Court.
    - ``simulation_end``    – full result JSON.

    The **last** yielded dict (``simulation_end``) contains the complete
    ``{"opinion": ..., "transcript": [...]}`` payload.
    """
    if config is None:
        config = get_config()
    if associate_ids is None:
        associate_ids = DEFAULT_ASSOCIATE_IDS

    participating_ids = [CHIEF_JUSTICE_ID] + list(associate_ids)
    llm = build_llm(config.llm)
    if config.llm.provider.lower() == "sagemaker":
        llm.region_name = config.aws.region
    num_rounds = config.simulation.num_debate_rounds
    use_tools = config.simulation.enable_tools
    max_tool_calls = config.simulation.max_tool_calls

    # ── Vector stores ───────────────────────────────────────────────────
    try:
        justice_stores = build_all_vectorstores(config, participating_ids)
        combined_store = build_combined_vectorstore(config, participating_ids)
    except Exception as e:
        logger.warning("Could not build vector stores: %s. Running without past opinions.", e)
        justice_stores = {}
        combined_store = None

    chief_retriever = (
        get_chief_justice_retriever(combined_store, k=config.simulation.max_opinion_references)
        if combined_store else None
    )
    justice_retrievers = {
        jid: get_justice_retriever(vs, k=config.simulation.max_opinion_references)
        for jid, vs in justice_stores.items()
    }

    transcript: List[Dict[str, Any]] = []
    chief_profile = JUSTICE_MAP[CHIEF_JUSTICE_ID]

    yield {"event": "simulation_start", "case_description": case_description,
           "justices": [CHIEF_JUSTICE_ID] + list(associate_ids),
           "total_rounds": num_rounds}

    # ── Chief opens case ────────────────────────────────────────────────
    precedents = _retrieve_opinions(chief_retriever, case_description)
    system_msg = SystemMessage(content=CHIEF_JUSTICE_SYSTEM.format(
        persona_description=chief_profile.persona_description,
        num_rounds=num_rounds,
    ))
    human_msg = HumanMessage(content=CHIEF_JUSTICE_OPEN_CASE.format(
        case_description=case_description,
        precedents=precedents,
    ))
    text = llm.invoke([system_msg, human_msg]).content
    transcript.append({"round": 0, "justice_id": CHIEF_JUSTICE_ID, "text": text})

    yield {"event": "chief_open_case", "round": 0,
           "justice": chief_profile.name, "text": text}

    round_prompt = text

    # ── Debate rounds ───────────────────────────────────────────────────
    for round_num in range(1, num_rounds + 1):
        responses: Dict[str, str] = {}

        for jid in associate_ids:
            profile = JUSTICE_MAP[jid]
            retriever = justice_retrievers.get(jid)
            past_opinions = _retrieve_opinions(retriever, case_description)

            other_text = "\n".join(
                f"{JUSTICE_MAP[oid].name}: {otxt}" for oid, otxt in responses.items()
            ) or "(You are the first to respond this round.)"

            sys_msg = SystemMessage(content=ASSOCIATE_JUSTICE_SYSTEM.format(
                persona_description=profile.persona_description,
                past_opinions=past_opinions,
            ))
            usr_msg = HumanMessage(content=ASSOCIATE_JUSTICE_RESPOND.format(
                round_label=f"Round {round_num}",
                round_prompt=round_prompt,
                other_responses=other_text,
                justice_name=profile.name,
            ))

            tool_calls_log: List[Dict[str, Any]] = []

            def _on_tool_call(name, args, output, _log=tool_calls_log):
                _log.append({"tool": name, "args": args, "output": str(output)[:500]})

            if use_tools:
                resp_text = _invoke_with_tools(
                    llm, [sys_msg, usr_msg], ALL_TOOLS,
                    max_tool_calls=max_tool_calls,
                    on_tool_call=_on_tool_call,
                )
            else:
                result = llm.invoke([sys_msg, usr_msg])
                resp_text = result.content

            responses[jid] = resp_text
            transcript.append({"round": round_num, "justice_id": jid, "text": resp_text})

            event_payload: Dict[str, Any] = {
                "event": "justice_response", "round": round_num,
                "justice_id": jid, "justice": profile.name, "text": resp_text,
            }
            if tool_calls_log:
                event_payload["tool_calls"] = tool_calls_log

            yield event_payload

        # Chief opens next round (unless this was the last one)
        if round_num < num_rounds:
            summary = _round_summary(transcript, round_num)
            sys_msg = SystemMessage(content=CHIEF_JUSTICE_SYSTEM.format(
                persona_description=chief_profile.persona_description,
                num_rounds=num_rounds,
            ))
            usr_msg = HumanMessage(content=CHIEF_JUSTICE_OPEN_ROUND.format(
                prev_round=round_num,
                round_summary=summary,
                current_round=round_num + 1,
                total_rounds=num_rounds,
            ))
            next_text = llm.invoke([sys_msg, usr_msg]).content
            transcript.append({"round": round_num + 1, "justice_id": CHIEF_JUSTICE_ID, "text": next_text})
            round_prompt = next_text

            yield {"event": "chief_next_round", "round": round_num + 1,
                   "justice": chief_profile.name, "text": next_text}

    # ── Final opinion ───────────────────────────────────────────────────
    full_transcript_text = _transcript_text(transcript)
    precedents = _retrieve_opinions(chief_retriever, case_description)

    sys_msg = SystemMessage(content=CHIEF_JUSTICE_SYSTEM.format(
        persona_description=chief_profile.persona_description,
        num_rounds=num_rounds,
    ))
    usr_msg = HumanMessage(content=CHIEF_JUSTICE_FINAL_OPINION.format(
        total_rounds=num_rounds,
        full_transcript=full_transcript_text,
        precedents=precedents,
    ))
    opinion_text = llm.invoke([sys_msg, usr_msg]).content
    transcript.append({"round": -1, "justice_id": CHIEF_JUSTICE_ID, "text": opinion_text})

    yield {"event": "chief_opinion", "justice": chief_profile.name, "text": opinion_text}

    # ── Final payload ───────────────────────────────────────────────────
    result = {
        "opinion": opinion_text,
        "transcript": [
            {
                "round": e["round"],
                "justice": JUSTICE_MAP.get(e["justice_id"], JusticeProfile(
                    justice_id=e["justice_id"], name=e["justice_id"],
                    title="", ideology="", persona_description=""
                )).name,
                "text": e["text"],
            }
            for e in transcript
        ],
    }

    yield {"event": "simulation_end", "result": result}
