"""
Local runner — test the simulation without deploying to SageMaker.

Usage:
    python run_local.py                          # stream output (default)
    python run_local.py "Your case description"  # stream with custom case
    python run_local.py --no-stream "Case desc"  # non-streaming mode
"""

import json
import sys
from src.graph import run_simulation, run_simulation_stream


DEFAULT_CASE = (
    "A state legislature passes a law requiring all social media platforms to verify "
    "the age of users and prohibit anyone under 16 from creating an account. A coalition "
    "of technology companies challenges the law, arguing it violates the First Amendment "
    "rights of minors and imposes an undue burden on interstate commerce. The state "
    "argues the law is a valid exercise of its police power to protect children."
)

_EVENT_LABELS = {
    "simulation_start": "🏛️  SIMULATION START",
    "chief_open_case": "⚖️  CHIEF JUSTICE OPENS CASE",
    "justice_response": "🗣️  JUSTICE RESPONSE",
    "chief_next_round": "⚖️  CHIEF JUSTICE — NEXT ROUND",
    "chief_opinion": "📜 OPINION OF THE COURT",
    "simulation_end": "✅ SIMULATION COMPLETE",
}


def main():
    args = [a for a in sys.argv[1:] if a != "--no-stream"]
    stream_mode = "--no-stream" not in sys.argv
    case = args[0] if args else DEFAULT_CASE

    print("=" * 80)
    print("SCOTUS SIMULATION — LOCAL RUN")
    print("=" * 80)
    print(f"\nCase:\n{case}\n")

    if stream_mode:
        print("Running simulation (streaming)...\n")
        result = None

        for event in run_simulation_stream(case):
            etype = event.get("event", "unknown")
            label = _EVENT_LABELS.get(etype, etype.upper())

            if etype == "simulation_start":
                justices = ", ".join(event.get("justices", []))
                rounds = event.get("total_rounds", "?")
                print(f"{label}")
                print(f"  Justices : {justices}")
                print(f"  Rounds   : {rounds}\n")

            elif etype in ("chief_open_case", "chief_next_round"):
                rnd = event.get("round", "")
                print(f"\n{label}  (Round {rnd})")
                print("-" * 60)
                print(event.get("text", ""))
                print()

            elif etype == "justice_response":
                rnd = event.get("round", "")
                name = event.get("justice", event.get("justice_id", ""))
                print(f"\n{label}  — {name}  (Round {rnd})")
                print("-" * 60)
                # Show tool calls if any
                tool_calls = event.get("tool_calls", [])
                if tool_calls:
                    print(f"  🔧 {len(tool_calls)} tool call(s):")
                    for tc in tool_calls:
                        tool_name = tc.get("tool", "?")
                        tool_args = tc.get("args", {})
                        tool_out = tc.get("output", "")
                        query_str = tool_args.get("query", str(tool_args))
                        print(f"     • {tool_name}(\"{query_str}\")")
                        # Show first 200 chars of output
                        preview = tool_out[:200] + "…" if len(tool_out) > 200 else tool_out
                        print(f"       → {preview}")
                    print()
                print(event.get("text", ""))
                print()

            elif etype == "chief_opinion":
                print(f"\n{'=' * 80}")
                print(label)
                print("=" * 80)
                print(event.get("text", ""))
                print()

            elif etype == "simulation_end":
                result = event.get("result", {})
                print(f"\n{label}\n")

            else:
                print(f"[{etype}] {json.dumps(event, indent=2, default=str)}\n")

        if result:
            with open("simulation_result.json", "w") as f:
                json.dump(result, f, indent=2, default=str)
            print("✅ Saved full result to simulation_result.json")

    else:
        print("Running simulation (non-streaming, this may take a while)...\n")
        result = run_simulation(case)

        print("=" * 80)
        print("OPINION OF THE COURT")
        print("=" * 80)
        print(result.get("opinion", "(no opinion)"))

        print("\n" + "=" * 80)
        print("FULL TRANSCRIPT")
        print("=" * 80)
        for entry in result.get("transcript", []):
            round_label = (
                "Opening" if entry["round"] == 0
                else "Final Opinion" if entry["round"] == -1
                else f"Round {entry['round']}"
            )
            print(f"\n--- {entry['justice']} ({round_label}) ---")
            print(entry["text"])

        with open("simulation_result.json", "w") as f:
            json.dump(result, f, indent=2, default=str)
        print("\n✅ Saved to simulation_result.json")


if __name__ == "__main__":
    main()
