# SCOTUS Simulation — Multi-Agent System

A **LangGraph** multi-agent system that simulates a Supreme Court oral argument and
decision.  Nine justice agents (1 Chief Justice + 8 Associate Justices) debate a
user-supplied case over 3 rounds, retrieve their own past opinions from an S3-backed
FAISS vector store, and produce a final ruling with a full transcript.

Designed for deployment on **AWS SageMaker** as a real-time inference endpoint.

---

## Architecture

```
User prompt (case description)
        │
        ▼
┌──────────────────┐
│  Chief Justice   │  Frames legal questions, opens Round 1
│  (Roberts)       │  Has access to ALL justices' past opinions
└───────┬──────────┘
        │
┌───────▼──────────────────────────────────────────────┐
│                   DEBATE LOOP (×3 rounds)             │
│  ┌──────────────────────────────────────────────┐    │
│  │  8 Associate Justices respond sequentially    │    │
│  │  Each retrieves their OWN past opinions       │    │
│  └──────────────────────────────────────────────┘    │
│  Chief Justice synthesizes & opens next round         │
└───────┬──────────────────────────────────────────────┘
        │
        ▼
┌──────────────────┐
│  Chief Justice   │  Delivers Opinion of the Court
│  Final Opinion   │  (majority, concurrences, dissents)
└───────┬──────────┘
        │
        ▼
JSON result: { opinion, transcript }
```

### Key Components

| File | Purpose |
|---|---|
| `src/config.py` | Centralized configuration (AWS, LLM provider, simulation params) |
| `src/llm.py` | LLM factory — SageMaker AI endpoint or HuggingFace models |
| `src/justices.py` | 9 justice profiles with personas, ideologies, focus areas |
| `src/prompts.py` | All prompt templates for Chief Justice and Associate Justices |
| `src/vectorstore.py` | S3 → FAISS vector store: per-justice + combined retriever |
| `src/graph.py` | **LangGraph** state graph: orchestration, debate loop, final opinion |
| `serve.py` | FastAPI server for SageMaker (`/ping` + `/invocations`) |
| `run_local.py` | Run the simulation locally without SageMaker |

---

## Quick Start (Local)

### 1. Install dependencies

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure environment

```bash
cp .env.example .env
# Edit .env with your AWS credentials, LLM provider, S3 bucket, etc.
```

### 3. Seed sample opinions in S3

```bash
python scripts/seed_opinions.py
```

### 4. Run locally

```bash
python run_local.py "A state passes a law banning all encryption..."
```

---

## Deploy to SageMaker

### 1. Build & push Docker image to ECR

```bash
python scripts/build_and_push.py
```

### 2. Set the ECR image URI

Add the output URI to your `.env`:

```
ECR_IMAGE_URI=123456789.dkr.ecr.us-east-1.amazonaws.com/scotus-simulation:latest
```

### 3. Deploy the endpoint

```bash
python scripts/deploy_sagemaker.py
```

### 4. Invoke the endpoint

```bash
python scripts/invoke_endpoint.py "A state legislature passes a law requiring..."
```

Or programmatically:

```python
import boto3, json

runtime = boto3.client("sagemaker-runtime")
response = runtime.invoke_endpoint(
    EndpointName="scotus-simulation-endpoint",
    ContentType="application/json",
    Body=json.dumps({
        "case_description": "A state passes a law banning all encryption..."
    }),
)
result = json.loads(response["Body"].read())
print(result["opinion"])
```

---

## S3 Vector Store Structure

```
s3://scotus-simulation-vectorstore/
└── opinions/
    ├── roberts/
    │   └── NFIB_v._Sebelius_(2012).json
    ├── thomas/
    │   └── McDonald_v._City_of_Chicago_(2010).json
    ├── sotomayor/
    │   └── Utah_v._Strieff_(2016).json
    └── ...
```

Each JSON file:

```json
{
  "case_name": "NFIB v. Sebelius (2012)",
  "year": "2012",
  "opinion_type": "majority",
  "text": "The Affordable Care Act's individual mandate..."
}
```

- **Associate Justices** retrieve only from their own `opinions/<justice_id>/` prefix.
- **Chief Justice** retrieves from a combined index across all justices.

---

## LLM Providers

Set `LLM_PROVIDER` in `.env` to choose between two back-ends:

### Option A — SageMaker AI (`LLM_PROVIDER=sagemaker`)

| Setting | `.env` variable | Notes |
|---|---|---|
| **LLM endpoint** | `SAGEMAKER_LLM_ENDPOINT_NAME` | Hosts a chat model (Llama 3, Mistral, Falcon via HuggingFace TGI or JumpStart) |
| **Embeddings endpoint** | `SAGEMAKER_EMBEDDINGS_ENDPOINT_NAME` | Hosts a sentence-transformers model for vector search |

Deploy your models to SageMaker first (via JumpStart, HuggingFace Hub, or a
custom container), then set the endpoint names in `.env`.

### Option B — HuggingFace (`LLM_PROVIDER=huggingface`)

| Setting | `.env` variable | Notes |
|---|---|---|
| **LLM model** | `HF_LLM_MODEL` | Any HF chat model (e.g., `mistralai/Mistral-7B-Instruct-v0.3`) |
| **Embeddings model** | `HF_EMBEDDINGS_MODEL` | Any sentence-transformers model (e.g., `sentence-transformers/all-MiniLM-L6-v2`) |
| **API token** | `HF_API_TOKEN` | Required for gated models and the Inference API |
| **Run locally** | `HF_LOCAL=true` | Loads models on-device via `transformers` instead of calling the HF API |

---

## Customization

- **Add more opinions**: Upload `.json` files to `s3://<bucket>/opinions/<justice_id>/`
- **Change number of rounds**: Set `NUM_DEBATE_ROUNDS` in config or update `SimulationConfig`
- **Swap justices**: Edit `JUSTICE_PROFILES` in `src/justices.py`
- **Change prompts**: Edit templates in `src/prompts.py`

---

## Project Structure

```
capstone_v2/
├── .env.example            # Environment variable template
├── Dockerfile              # SageMaker-compatible container
├── requirements.txt        # Python dependencies
├── serve.py                # FastAPI server (SageMaker entry point)
├── run_local.py            # Local simulation runner
├── src/
│   ├── __init__.py
│   ├── config.py           # Configuration management
│   ├── llm.py              # LLM provider factory
│   ├── justices.py         # Justice profiles & personas
│   ├── prompts.py          # Prompt templates
│   ├── vectorstore.py      # S3 + FAISS vector store
│   └── graph.py            # LangGraph multi-agent workflow
└── scripts/
    ├── seed_opinions.py    # Seed S3 with sample opinions
    ├── build_and_push.py   # Build Docker → push to ECR
    ├── deploy_sagemaker.py # Deploy to SageMaker endpoint
    └── invoke_endpoint.py  # Test the deployed endpoint
```

---

## License

MIT
