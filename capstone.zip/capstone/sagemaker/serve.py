#!/usr/bin/env python3
"""
Flask-based model server for SageMaker hosting.

SageMaker expects an HTTP server on port 8080 with:
    GET  /ping         → health check
    POST /invocations  → inference
"""

from __future__ import annotations

import logging
import os

from flask import Flask, Response, jsonify, request

# Import the handler functions
from inference import input_fn, model_fn, output_fn, predict_fn

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Load the model once at startup
MODEL_DIR = os.environ.get("SM_MODEL_DIR", "/opt/ml/model")
model = None


def _ensure_model():
    global model
    if model is None:
        logger.info("Loading model …")
        model = model_fn(MODEL_DIR)
        logger.info("Model loaded.")


@app.route("/ping", methods=["GET"])
def ping():
    """Health check endpoint required by SageMaker."""
    _ensure_model()
    return Response(response='{"status": "healthy"}',
                    status=200, mimetype="application/json")


@app.route("/invocations", methods=["POST"])
def invoke():
    """Inference endpoint."""
    _ensure_model()

    content_type = request.content_type or "application/json"
    accept = request.accept_mimetypes.best or "application/json"

    try:
        input_data = input_fn(request.data.decode("utf-8"), content_type)
        prediction = predict_fn(input_data, model)
        result = output_fn(prediction, accept)
        return Response(response=result, status=200, mimetype=accept)
    except Exception as e:
        logger.exception("Invocation failed")
        return jsonify({"status": "error", "error": str(e)}), 500


if __name__ == "__main__":
    _ensure_model()
    port = int(os.environ.get("SAGEMAKER_BIND_TO_PORT", "8080"))
    app.run(host="0.0.0.0", port=port)
