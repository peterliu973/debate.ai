"""
Deploy the Supreme Court Debate system to AWS SageMaker.

This script:
1. Builds and pushes the Docker image to ECR
2. Creates a SageMaker Model
3. Creates an Endpoint Configuration
4. Deploys the Endpoint

Prerequisites:
    - AWS CLI configured with appropriate permissions
    - Docker installed and running
    - OPENAI_API_KEY available as a secret or env var

Usage:
    python sagemaker/deploy.py --region us-east-1 --instance ml.m5.xlarge
"""

from __future__ import annotations

import argparse
import json
import logging
import subprocess
import time

import boto3
import sagemaker
from sagemaker.model import Model

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

IMAGE_NAME = "scotus-debate-sagemaker"
MODEL_NAME = "scotus-debate-model"
ENDPOINT_CONFIG_NAME = "scotus-debate-endpoint-config"
ENDPOINT_NAME = "scotus-debate-endpoint"


def get_account_id() -> str:
    return boto3.client("sts").get_caller_identity()["Account"]


def get_ecr_uri(region: str) -> str:
    account = get_account_id()
    return f"{account}.dkr.ecr.{region}.amazonaws.com/{IMAGE_NAME}:latest"


# ---------------------------------------------------------------------------
# Step 1: Build & push Docker image to ECR
# ---------------------------------------------------------------------------

def build_and_push_image(region: str):
    """Build the Docker image and push to Amazon ECR."""
    account = get_account_id()
    ecr_uri = get_ecr_uri(region)
    ecr_repo = f"{account}.dkr.ecr.{region}.amazonaws.com"

    logger.info("Authenticating with ECR …")
    login_cmd = (
        f"aws ecr get-login-password --region {region} | "
        f"docker login --username AWS --password-stdin {ecr_repo}"
    )
    subprocess.run(login_cmd, shell=True, check=True)

    # Create ECR repository if it doesn't exist
    ecr_client = boto3.client("ecr", region_name=region)
    try:
        ecr_client.create_repository(repositoryName=IMAGE_NAME)
        logger.info(f"Created ECR repository: {IMAGE_NAME}")
    except ecr_client.exceptions.RepositoryAlreadyExistsException:
        logger.info(f"ECR repository already exists: {IMAGE_NAME}")

    logger.info("Building Docker image …")
    subprocess.run(
        ["docker", "build", "-t", IMAGE_NAME, "-f", "sagemaker/Dockerfile", "."],
        check=True,
    )

    logger.info("Tagging and pushing image …")
    subprocess.run(["docker", "tag", f"{IMAGE_NAME}:latest", ecr_uri], check=True)
    subprocess.run(["docker", "push", ecr_uri], check=True)

    logger.info(f"Image pushed: {ecr_uri}")
    return ecr_uri


# ---------------------------------------------------------------------------
# Step 2: Create SageMaker Model + Endpoint
# ---------------------------------------------------------------------------

def deploy_endpoint(region: str, instance_type: str, openai_api_key: str,
                    llm_model: str = "gpt-4o"):
    """Create a SageMaker endpoint for the debate system."""
    sess = sagemaker.Session(boto_session=boto3.Session(region_name=region))
    role = sagemaker.get_execution_role()
    ecr_uri = get_ecr_uri(region)

    logger.info("Creating SageMaker Model …")

    model = Model(
        image_uri=ecr_uri,
        role=role,
        sagemaker_session=sess,
        name=MODEL_NAME,
        env={
            "OPENAI_API_KEY": openai_api_key,
            "LLM_MODEL_NAME": llm_model,
            "SAGEMAKER_PROGRAM": "serve.py",
        },
    )

    logger.info(f"Deploying to endpoint '{ENDPOINT_NAME}' on {instance_type} …")

    predictor = model.deploy(
        initial_instance_count=1,
        instance_type=instance_type,
        endpoint_name=ENDPOINT_NAME,
        container_startup_health_check_timeout=600,  # graph compilation can take time
    )

    logger.info(f"Endpoint deployed: {ENDPOINT_NAME}")
    return predictor


# ---------------------------------------------------------------------------
# Step 3: Test the endpoint
# ---------------------------------------------------------------------------

def test_endpoint(region: str):
    """Send a test invocation to the deployed endpoint."""
    runtime = boto3.client("sagemaker-runtime", region_name=region)

    payload = json.dumps({
        "max_questioning_rounds": 1,  # quick test with 1 round
    })

    logger.info("Sending test invocation …")
    response = runtime.invoke_endpoint(
        EndpointName=ENDPOINT_NAME,
        ContentType="application/json",
        Accept="application/json",
        Body=payload,
    )

    result = json.loads(response["Body"].read().decode("utf-8"))
    logger.info(f"Status: {result.get('status')}")
    logger.info(f"Decision: {result.get('final_decision')}")
    logger.info(f"Votes: {result.get('votes')}")

    return result


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------

def cleanup(region: str):
    """Delete the SageMaker endpoint and associated resources."""
    sm_client = boto3.client("sagemaker", region_name=region)

    logger.info("Deleting endpoint …")
    try:
        sm_client.delete_endpoint(EndpointName=ENDPOINT_NAME)
    except Exception as e:
        logger.warning(f"Could not delete endpoint: {e}")

    logger.info("Deleting endpoint config …")
    try:
        sm_client.delete_endpoint_config(
            EndpointConfigName=ENDPOINT_CONFIG_NAME
        )
    except Exception as e:
        logger.warning(f"Could not delete endpoint config: {e}")

    logger.info("Deleting model …")
    try:
        sm_client.delete_model(ModelName=MODEL_NAME)
    except Exception as e:
        logger.warning(f"Could not delete model: {e}")

    logger.info("Cleanup complete.")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Deploy SCOTUS Debate to SageMaker")
    parser.add_argument("--region", default="us-east-1")
    parser.add_argument("--instance", default="ml.m5.xlarge",
                        help="SageMaker instance type")
    parser.add_argument("--openai-key", required=True,
                        help="OpenAI API key for the LLM")
    parser.add_argument("--llm-model", default="gpt-4o",
                        help="LLM model name (default: gpt-4o)")
    parser.add_argument("--action", choices=["deploy", "test", "cleanup", "all"],
                        default="all")
    args = parser.parse_args()

    if args.action in ("deploy", "all"):
        build_and_push_image(args.region)
        deploy_endpoint(args.region, args.instance, args.openai_key, args.llm_model)

    if args.action in ("test", "all"):
        # Wait for endpoint to be ready
        if args.action == "all":
            logger.info("Waiting 60s for endpoint to initialize …")
            time.sleep(60)
        test_endpoint(args.region)

    if args.action == "cleanup":
        cleanup(args.region)


if __name__ == "__main__":
    main()
