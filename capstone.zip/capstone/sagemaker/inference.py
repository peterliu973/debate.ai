"""
SageMaker inference handler – implements the four required functions
for a custom SageMaker inference container:

    model_fn    → load the LangGraph graph
    input_fn    → deserialize incoming request
    predict_fn  → run the debate
    output_fn   → serialize the response

This module is the entrypoint referenced in the Dockerfile / serve script.
"""

from __future__ import annotations

import json
import logging
import os
import traceback
from typing import Any

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# SageMaker handler functions
# ---------------------------------------------------------------------------

def model_fn(model_dir: str) -> Any:
    """Load / compile the LangGraph debate graph.

    SageMaker calls this once when the endpoint starts. The ``model_dir``
    points to the extracted model artifact (if any). For this project the
    graph is built in-memory so we simply import it.
    """
    logger.info("Loading Supreme Court debate graph …")

    # Allow overriding the LLM model via an environment variable set in
    # the SageMaker Model definition.
    os.environ.setdefault("LLM_MODEL_NAME", "gpt-4o")

    from supreme_court_debate.graph import build_graph
    graph = build_graph()
    logger.info("Graph compiled successfully.")
    return graph


def input_fn(request_body: str, content_type: str = "application/json") -> dict:
    """Deserialize the incoming request body.

    Expected JSON schema::

        {
            "case_info": { ... },           # optional – defaults to sample case
            "justices": [ ... ],            # optional – defaults to 9 justices
            "max_questioning_rounds": 2,    # optional
            "stream": false                 # optional – if true, returns updates
        }
    """
    if content_type != "application/json":
        raise ValueError(f"Unsupported content type: {content_type}")

    data = json.loads(request_body)
    return data


def predict_fn(input_data: dict, model: Any) -> dict:
    """Run the debate graph end-to-end and return the final state."""

    from supreme_court_debate.config import DEFAULT_JUSTICES, SAMPLE_CASE

    case_info = input_data.get("case_info") or SAMPLE_CASE
    justices = input_data.get("justices") or DEFAULT_JUSTICES
    max_rounds = input_data.get("max_questioning_rounds", 2)
    do_stream = input_data.get("stream", False)

    initial_state = {
        "messages": [],
        "case_info": case_info,
        "justices": justices,
        "max_questioning_rounds": max_rounds,
    }

    graph = model  # the compiled StateGraph

    try:
        if do_stream:
            # Collect streamed updates into a list
            updates = []
            for event in graph.stream(initial_state, stream_mode="updates"):
                for node_name, update in event.items():
                    msgs = update.get("messages", [])
                    for m in msgs:
                        updates.append({
                            "node": node_name,
                            "speaker": getattr(m, "name", node_name),
                            "content": m.content,
                        })
            return {"status": "completed", "updates": updates}
        else:
            final_state = graph.invoke(initial_state)

            # Serialize messages for JSON transport
            messages = []
            for m in final_state.get("messages", []):
                messages.append({
                    "role": getattr(m, "type", "ai"),
                    "name": getattr(m, "name", "unknown"),
                    "content": m.content,
                })

            return {
                "status": "completed",
                "final_decision": final_state.get("final_decision", ""),
                "votes": final_state.get("votes", {}),
                "majority_opinion": final_state.get("majority_opinion", ""),
                "dissenting_opinions": final_state.get("dissenting_opinions", []),
                "concurring_opinions": final_state.get("concurring_opinions", []),
                "transcript": messages,
            }
    except Exception as exc:
        logger.error(f"Debate execution failed: {exc}")
        logger.error(traceback.format_exc())
        return {"status": "error", "error": str(exc)}


def output_fn(prediction: dict, accept: str = "application/json") -> str:
    """Serialize the prediction result."""
    if accept != "application/json":
        raise ValueError(f"Unsupported accept type: {accept}")
    return json.dumps(prediction, indent=2, default=str)
