"""
Client helper – call the deployed SageMaker endpoint from anywhere.

Usage:
    from sagemaker.client import SupremeCourtDebateClient

    client = SupremeCourtDebateClient(endpoint_name="scotus-debate-endpoint")
    result = client.run_debate()
    print(result["final_decision"])
"""

from __future__ import annotations

import json
from typing import Any, Optional

import boto3


class SupremeCourtDebateClient:
    """Convenience client for the SageMaker-hosted Supreme Court debate."""

    def __init__(self, endpoint_name: str = "scotus-debate-endpoint",
                 region: str = "us-east-1"):
        self.endpoint_name = endpoint_name
        self.runtime = boto3.client("sagemaker-runtime", region_name=region)

    def run_debate(
        self,
        case_info: Optional[dict] = None,
        justices: Optional[list[dict]] = None,
        max_questioning_rounds: int = 2,
        stream: bool = False,
    ) -> dict:
        """Invoke the debate endpoint.

        Parameters
        ----------
        case_info : dict, optional
            Custom case definition. Uses the built-in sample case if omitted.
        justices : list[dict], optional
            Custom justice profiles. Uses the default 9-justice bench if omitted.
        max_questioning_rounds : int
            How many rounds of questioning per side (default 2).
        stream : bool
            If True, return per-node updates instead of a single final state.

        Returns
        -------
        dict
            Result containing final_decision, votes, majority_opinion,
            dissenting_opinions, and the full transcript.
        """
        payload: dict[str, Any] = {
            "max_questioning_rounds": max_questioning_rounds,
            "stream": stream,
        }
        if case_info:
            payload["case_info"] = case_info
        if justices:
            payload["justices"] = justices

        response = self.runtime.invoke_endpoint(
            EndpointName=self.endpoint_name,
            ContentType="application/json",
            Accept="application/json",
            Body=json.dumps(payload),
        )

        return json.loads(response["Body"].read().decode("utf-8"))

    def run_custom_case(
        self,
        case_name: str,
        question_presented: str,
        petitioner_brief: str,
        respondent_brief: str,
        lower_court_decision: str,
        docket_number: str = "24-0001",
        key_precedents: Optional[list[str]] = None,
        max_rounds: int = 2,
    ) -> dict:
        """Convenience method to run a custom case with minimal boilerplate."""
        case_info = {
            "case_name": case_name,
            "docket_number": docket_number,
            "question_presented": question_presented,
            "petitioner_brief": petitioner_brief,
            "respondent_brief": respondent_brief,
            "lower_court_decision": lower_court_decision,
            "key_precedents": key_precedents or [],
            "amicus_briefs": [],
        }
        return self.run_debate(case_info=case_info,
                               max_questioning_rounds=max_rounds)

    def get_transcript(self, result: dict) -> str:
        """Format a result dict into a readable transcript."""
        lines = []
        for msg in result.get("transcript", []):
            name = msg.get("name", "Unknown")
            content = msg.get("content", "")
            lines.append(f"\n{'='*70}")
            lines.append(f"  {name}")
            lines.append(f"{'='*70}")
            lines.append(content)
        return "\n".join(lines)
