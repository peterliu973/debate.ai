"""Unit tests for state definitions."""

import pytest

from supreme_court_debate.state import (
    CaseInfo,
    DebatePhase,
    JusticeLeaning,
    JusticeProfile,
    Vote,
)


class TestDebatePhase:
    def test_all_phases_exist(self):
        phases = [p.value for p in DebatePhase]
        assert "case_introduction" in phases
        assert "petitioner_opening" in phases
        assert "voting" in phases
        assert "case_concluded" in phases

    def test_phase_count(self):
        assert len(DebatePhase) == 10


class TestJusticeProfile:
    def test_default_values(self):
        j = JusticeProfile(name="Test", leaning=JusticeLeaning.MODERATE)
        assert j.name == "Test"
        assert j.vote is None
        assert j.specialty_areas == []
        assert j.temperament == "measured"

    def test_vote_assignment(self):
        j = JusticeProfile(name="Test", leaning=JusticeLeaning.LIBERAL)
        j.vote = Vote.REVERSE
        assert j.vote == Vote.REVERSE


class TestCaseInfo:
    def test_creation(self):
        case = CaseInfo(
            case_name="Test v. Case",
            docket_number="23-001",
            lower_court_decision="Affirmed",
            question_presented="Whether ...",
            petitioner_brief="Petitioner argues ...",
            respondent_brief="Respondent argues ...",
        )
        assert case.case_name == "Test v. Case"
        assert case.key_precedents == []
