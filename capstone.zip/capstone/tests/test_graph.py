"""Unit tests for graph construction (does not invoke LLM calls)."""

import pytest

from supreme_court_debate.graph import build_graph
from supreme_court_debate.state import SupremeCourtState


class TestGraphConstruction:
    def test_graph_compiles(self):
        """The graph should compile without errors."""
        graph = build_graph()
        assert graph is not None

    def test_graph_has_expected_nodes(self):
        """All expected nodes should be present in the graph."""
        graph = build_graph()
        node_names = set(graph.get_graph().nodes.keys())
        expected = {
            "clerk_intro",
            "petitioner_open",
            "justice_q_petitioner",
            "petitioner_answer",
            "respondent_open",
            "justice_q_respondent",
            "respondent_answer",
            "petitioner_rebuttal",
            "justice_deliberate",
            "justice_vote",
            "majority_opinion",
            "dissenting_opinions",
            "clerk_conclude",
        }
        # Graph may also include __start__ and __end__ nodes
        assert expected.issubset(node_names), (
            f"Missing nodes: {expected - node_names}"
        )


class TestRoutingHelpers:
    def test_route_petitioner_to_respondent(self):
        from supreme_court_debate.graph import _route_after_petitioner_answer
        state = {"current_phase": "respondent_opening"}
        assert _route_after_petitioner_answer(state) == "respondent_open"

    def test_route_petitioner_loop(self):
        from supreme_court_debate.graph import _route_after_petitioner_answer
        state = {"current_phase": "petitioner_questioning"}
        assert _route_after_petitioner_answer(state) == "justice_q_petitioner"

    def test_route_respondent_to_rebuttal(self):
        from supreme_court_debate.graph import _route_after_respondent_answer
        state = {"current_phase": "petitioner_rebuttal"}
        assert _route_after_respondent_answer(state) == "petitioner_rebuttal"

    def test_route_respondent_loop(self):
        from supreme_court_debate.graph import _route_after_respondent_answer
        state = {"current_phase": "respondent_questioning"}
        assert _route_after_respondent_answer(state) == "justice_q_respondent"

    def test_route_deliberation_to_vote(self):
        from supreme_court_debate.graph import _route_after_deliberation
        state = {"current_phase": "voting"}
        assert _route_after_deliberation(state) == "justice_vote"

    def test_route_deliberation_loop(self):
        from supreme_court_debate.graph import _route_after_deliberation
        state = {"current_phase": "justice_deliberation"}
        assert _route_after_deliberation(state) == "justice_deliberate"
