# Supreme Court Multi-Agent Debate System

A **LangGraph**-powered multi-agent simulation of a United States Supreme Court oral argument and decision, designed for deployment on **AWS SageMaker**.

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    LangGraph StateGraph                 │
│                                                         │
│  ┌───────────┐   ┌──────────────┐   ┌───────────────┐  │
│  │   Clerk   │──▶│  Petitioner  │──▶│   Justices     │  │
│  │   Intro   │   │   Opening    │   │  Questioning   │  │
│  └───────────┘   └──────────────┘   └───────┬───────┘  │
│                                             │          │
│                                    ┌────────▼────────┐  │
│                                    │   Petitioner    │  │
│                                    │    Answers      │  │
│                                    └────────┬────────┘  │
│                                             │ (loop)   │
│  ┌───────────┐   ┌──────────────┐   ┌───────▼───────┐  │
│  │  Clerk    │◀──│   Opinions   │◀──│  Respondent   │  │
│  │ Conclude  │   │   Writing    │   │   Phase       │  │
│  └───────────┘   └──────────────┘   └───────────────┘  │
│                         ▲                               │
│                  ┌──────┴──────┐                        │
│                  │   Voting &  │                        │
│                  │ Deliberation│                        │
│                  └─────────────┘                        │
└─────────────────────────────────────────────────────────┘
```

## Agents

| Agent | Role | Count |
|-------|------|-------|
| **Court Clerk** | Announces case, records proceedings, announces decision | 1 |
| **Chief Justice** | Presides, questions counsel, writes majority opinion | 1 |
| **Associate Justices** | Question counsel, deliberate, vote, write opinions | 8 |
| **Petitioner Counsel** | Argues to reverse the lower court decision | 1 |
| **Respondent Counsel** | Argues to affirm the lower court decision | 1 |

## Debate Flow

1. **Case Introduction** – Clerk announces the case and procedural posture
2. **Petitioner Opening** – Petitioner counsel presents opening argument
3. **Petitioner Questioning** – Each justice questions petitioner (multiple rounds)
4. **Respondent Opening** – Respondent counsel presents opening argument
5. **Respondent Questioning** – Each justice questions respondent (multiple rounds)
6. **Petitioner Rebuttal** – Petitioner delivers a rebuttal
7. **Deliberation** – Each justice deliberates on the merits
8. **Voting** – All 9 justices cast votes (affirm/reverse)
9. **Opinion Writing** – Majority and dissenting opinions are written
10. **Conclusion** – Clerk announces the final decision

## Project Structure

```
capstone/
├── supreme_court_debate/          # Core LangGraph package
│   ├── __init__.py
│   ├── state.py                   # Graph state & data models
│   ├── prompts.py                 # All prompt templates
│   ├── agents.py                  # Agent node functions
│   ├── graph.py                   # LangGraph workflow definition
│   ├── config.py                  # Default justices & sample case
│   └── run.py                     # CLI runner for local testing
├── sagemaker/                     # AWS SageMaker deployment
│   ├── Dockerfile                 # Container definition
│   ├── inference.py               # SageMaker handler functions
│   ├── serve.py                   # Flask model server
│   ├── serve                      # SageMaker entrypoint script
│   ├── deploy.py                  # Build, push, deploy script
│   └── client.py                  # Client helper for calling endpoint
├── tests/                         # Unit tests
│   ├── test_state.py
│   └── test_graph.py
├── notebooks/                     # Jupyter notebooks
│   └── demo.ipynb                 # Interactive demo notebook
├── requirements.txt
└── README.md
```

## Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Set your API key

```bash
export OPENAI_API_KEY="sk-..."
```

### 3. Run locally

```bash
# Run with the built-in sample case
python -m supreme_court_debate.run

# Run with a custom case file
python -m supreme_court_debate.run --case my_case.json --max-rounds 2
```

### 4. Deploy to SageMaker

```bash
# Build, push to ECR, and deploy endpoint
python sagemaker/deploy.py \
    --region us-east-1 \
    --instance ml.m5.xlarge \
    --openai-key "$OPENAI_API_KEY" \
    --action all

# Test the endpoint
python sagemaker/deploy.py --region us-east-1 --action test

# Clean up
python sagemaker/deploy.py --region us-east-1 --action cleanup
```

### 5. Call from your application

```python
from sagemaker.client import SupremeCourtDebateClient

client = SupremeCourtDebateClient(endpoint_name="scotus-debate-endpoint")

# Run the default case
result = client.run_debate(max_questioning_rounds=2)

print(f"Decision: {result['final_decision']}")
print(f"Votes: {result['votes']}")
print(client.get_transcript(result))

# Run a custom case
result = client.run_custom_case(
    case_name="Smith v. State of California",
    question_presented="Whether ...",
    petitioner_brief="The petitioner argues ...",
    respondent_brief="The respondent argues ...",
    lower_court_decision="The Ninth Circuit held ...",
    key_precedents=["Marbury v. Madison (1803)"],
)
```

## Custom Case Format

Supply a JSON file with this schema:

```json
{
    "case_name": "Doe v. United States",
    "docket_number": "24-1234",
    "lower_court_decision": "The circuit court held that ...",
    "question_presented": "Whether the ... violates the ...",
    "petitioner_brief": "The petitioner argues ...",
    "respondent_brief": "The respondent argues ...",
    "key_precedents": ["Case A (year)", "Case B (year)"],
    "amicus_briefs": ["Organization — supporting petitioner"]
}
```

## Configuration

| Environment Variable | Default | Description |
|---------------------|---------|-------------|
| `OPENAI_API_KEY` | — | Required. OpenAI API key |
| `LLM_MODEL_NAME` | `gpt-4o` | LLM model to use |

## License

MIT
