"""
Default case configurations and justice profiles for the simulation.
"""

from .state import JusticeLeaning

# ---------------------------------------------------------------------------
# Default 9-justice bench (names are fictional to avoid real-world bias)
# ---------------------------------------------------------------------------

DEFAULT_JUSTICES = [
    {
        "name": "Chief Justice Morrison",
        "leaning": JusticeLeaning.MODERATE.value,
        "specialty_areas": ["constitutional law", "separation of powers", "federalism"],
        "temperament": "authoritative and balanced",
    },
    {
        "name": "Justice Harrington",
        "leaning": JusticeLeaning.CONSERVATIVE.value,
        "specialty_areas": ["originalism", "Second Amendment", "religious liberty"],
        "temperament": "direct and skeptical",
    },
    {
        "name": "Justice Okafor",
        "leaning": JusticeLeaning.LIBERAL.value,
        "specialty_areas": ["civil rights", "equal protection", "voting rights"],
        "temperament": "empathetic and probing",
    },
    {
        "name": "Justice Chen",
        "leaning": JusticeLeaning.MODERATE.value,
        "specialty_areas": ["administrative law", "statutory interpretation", "commerce clause"],
        "temperament": "methodical and technical",
    },
    {
        "name": "Justice Alvarez",
        "leaning": JusticeLeaning.LIBERAL.value,
        "specialty_areas": ["criminal procedure", "Fourth Amendment", "due process"],
        "temperament": "passionate and rhetorical",
    },
    {
        "name": "Justice Whitfield",
        "leaning": JusticeLeaning.CONSERVATIVE.value,
        "specialty_areas": ["property rights", "takings clause", "contracts"],
        "temperament": "formal and textualist",
    },
    {
        "name": "Justice Nakamura",
        "leaning": JusticeLeaning.MODERATE.value,
        "specialty_areas": ["intellectual property", "technology law", "First Amendment"],
        "temperament": "inquisitive and hypothetical-driven",
    },
    {
        "name": "Justice Brooks",
        "leaning": JusticeLeaning.CONSERVATIVE.value,
        "specialty_areas": ["executive power", "national security", "immigration"],
        "temperament": "pointed and efficiency-minded",
    },
    {
        "name": "Justice Delacroix",
        "leaning": JusticeLeaning.LIBERAL.value,
        "specialty_areas": ["international law", "human rights", "environmental law"],
        "temperament": "philosophical and expansive",
    },
]

# ---------------------------------------------------------------------------
# Sample case: a fictional but realistic constitutional controversy
# ---------------------------------------------------------------------------

SAMPLE_CASE = {
    "case_name": "National Digital Privacy Coalition v. United States",
    "docket_number": "23-4159",
    "lower_court_decision": (
        "The D.C. Circuit Court of Appeals upheld the constitutionality of the "
        "Comprehensive Digital Surveillance Act (CDSA), which authorizes federal "
        "agencies to collect metadata from digital communications without a warrant "
        "when there is a reasonable suspicion of involvement in activities threatening "
        "national security. The lower court held that metadata collection does not "
        "constitute a 'search' under the Fourth Amendment, relying on the third-party "
        "doctrine established in Smith v. Maryland (1979)."
    ),
    "question_presented": (
        "Whether the warrantless collection of digital communications metadata "
        "under the Comprehensive Digital Surveillance Act violates the Fourth "
        "Amendment's prohibition against unreasonable searches and seizures, "
        "in light of the Supreme Court's decision in Carpenter v. United States "
        "(2018) which held that accessing historical cell-site location information "
        "constitutes a search under the Fourth Amendment."
    ),
    "petitioner_brief": (
        "The CDSA's warrantless metadata collection program violates the Fourth "
        "Amendment. Following Carpenter v. United States, the third-party doctrine "
        "cannot justify bulk collection of digital metadata, which reveals intimate "
        "details of a person's life — their associations, movements, reading habits, "
        "and political affiliations. The volume, variety, and persistence of modern "
        "digital metadata is qualitatively different from the phone numbers at issue "
        "in Smith v. Maryland. A warrant requirement is essential to protect the "
        "reasonable expectation of privacy in the digital age."
    ),
    "respondent_brief": (
        "The CDSA's metadata collection program is constitutional. Metadata — "
        "records of communications rather than their content — has long been "
        "understood to fall outside Fourth Amendment protection because individuals "
        "voluntarily convey this information to third-party service providers. "
        "Carpenter was narrowly decided and explicitly declined to disturb the "
        "third-party doctrine as a whole. National security interests provide a "
        "compelling government interest, and the CDSA includes significant "
        "oversight mechanisms including FISA court review."
    ),
    "key_precedents": [
        "Carpenter v. United States (2018)",
        "Smith v. Maryland (1979)",
        "Katz v. United States (1967)",
        "Riley v. California (2014)",
        "United States v. Jones (2012)",
        "Kyllo v. United States (2001)",
    ],
    "amicus_briefs": [
        "Electronic Frontier Foundation — supporting petitioner",
        "American Civil Liberties Union — supporting petitioner",
        "National Association of Attorneys General — supporting respondent",
        "Former National Security Officials — supporting respondent",
    ],
}
