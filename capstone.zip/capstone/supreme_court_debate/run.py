"""
CLI runner – execute the Supreme Court debate locally for testing.

Usage:
    python -m supreme_court_debate.run                   # uses default case
    python -m supreme_court_debate.run --case case.json  # custom case
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .config import DEFAULT_JUSTICES, SAMPLE_CASE
from .graph import build_graph


def _load_case(path: str | None) -> dict:
    if path:
        return json.loads(Path(path).read_text())
    return SAMPLE_CASE


def run_debate(case: dict | None = None,
               justices: list[dict] | None = None,
               max_rounds: int = 2,
               stream: bool = True) -> dict:
    """Run the full debate and return the final state."""

    case = case or SAMPLE_CASE
    justices = justices or DEFAULT_JUSTICES

    initial_state = {
        "messages": [],
        "case_info": case,
        "justices": justices,
        "max_questioning_rounds": max_rounds,
    }

    graph = build_graph()

    if stream:
        final_state = None
        for event in graph.stream(initial_state, stream_mode="updates"):
            for node_name, update in event.items():
                msgs = update.get("messages", [])
                for m in msgs:
                    label = getattr(m, "name", node_name)
                    print(f"\n{'='*80}")
                    print(f"  [{label}]")
                    print(f"{'='*80}")
                    print(m.content)
                    print()
            final_state = event
        return final_state or {}
    else:
        return graph.invoke(initial_state)


def main():
    parser = argparse.ArgumentParser(description="Run Supreme Court Debate Simulation")
    parser.add_argument("--case", type=str, default=None,
                        help="Path to case JSON file (uses sample case if omitted)")
    parser.add_argument("--max-rounds", type=int, default=2,
                        help="Max questioning rounds per side (default: 2)")
    parser.add_argument("--no-stream", action="store_true",
                        help="Disable streaming output")
    args = parser.parse_args()

    case = _load_case(args.case)
    final = run_debate(case=case, max_rounds=args.max_rounds,
                       stream=not args.no_stream)

    # Print summary
    print("\n" + "=" * 80)
    print("  FINAL DECISION")
    print("=" * 80)
    if isinstance(final, dict):
        # When streaming, final is the last event dict
        for node_name, update in final.items():
            if "final_decision" in update:
                print(f"  Decision: {update['final_decision']}")
            if "votes" in update:
                print(f"  Votes: {update['votes']}")


if __name__ == "__main__":
    main()
