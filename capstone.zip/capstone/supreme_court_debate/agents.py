"""
Agent definitions – each function creates an LLM-backed agent
that fulfils a specific role in the Supreme Court simulation.
"""

from __future__ import annotations

from typing import Any

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI

from . import prompts
from .state import CaseInfo, JusticeProfile, SupremeCourtState


# ---------------------------------------------------------------------------
# LLM factory (swap model for SageMaker-hosted endpoint as needed)
# ---------------------------------------------------------------------------

def _get_llm(temperature: float = 0.7, model: str | None = None) -> ChatOpenAI:
    """Return the LLM used by all agents.

    When running on SageMaker you can override *model* via the
    ``LLM_MODEL_NAME`` env-var or the config passed at deploy time.
    """
    import os

    model = model or os.getenv("LLM_MODEL_NAME", "gpt-4o")
    return ChatOpenAI(model=model, temperature=temperature)


def _case(state: SupremeCourtState) -> dict:
    """Extract case_info dict from state, with safe defaults."""
    return state.get("case_info") or {}


def _justice_by_index(state: SupremeCourtState, idx: int) -> dict:
    """Retrieve a justice profile dict by index."""
    justices = state.get("justices", [])
    if 0 <= idx < len(justices):
        return justices[idx]
    return {"name": "Unknown", "leaning": "moderate",
            "specialty_areas": "general law", "temperament": "measured"}


# ═══════════════════════════════════════════════════════════════════════════
# Node functions  (each takes state, returns partial-state update dict)
# ═══════════════════════════════════════════════════════════════════════════


def court_clerk_introduce(state: SupremeCourtState) -> dict:
    """Clerk announces the case and sets the stage."""
    case = _case(state)
    llm = _get_llm(temperature=0.3)

    system = prompts.COURT_CLERK_SYSTEM.format(
        case_name=case.get("case_name", "Unknown"),
        docket_number=case.get("docket_number", "00-000"),
    )
    user = prompts.CASE_INTRODUCTION_PROMPT.format(
        case_name=case.get("case_name", ""),
        docket_number=case.get("docket_number", ""),
        question_presented=case.get("question_presented", ""),
        lower_court_decision=case.get("lower_court_decision", ""),
    )

    response = llm.invoke([SystemMessage(content=system),
                           HumanMessage(content=user)])
    return {
        "messages": [AIMessage(content=f"[CLERK] {response.content}",
                               name="CourtClerk")],
        "current_phase": "petitioner_opening",
        "phase_history": ["case_introduction"],
    }


def petitioner_opening(state: SupremeCourtState) -> dict:
    """Petitioner counsel delivers opening argument."""
    case = _case(state)
    llm = _get_llm()

    system = prompts.PETITIONER_COUNSEL_SYSTEM.format(
        case_name=case.get("case_name", ""),
        petitioner_brief=case.get("petitioner_brief", ""),
        lower_court_decision=case.get("lower_court_decision", ""),
        key_precedents=", ".join(case.get("key_precedents", [])),
    )
    user = prompts.OPENING_ARGUMENT_PROMPT

    response = llm.invoke([SystemMessage(content=system),
                           HumanMessage(content=user)])
    return {
        "messages": [AIMessage(content=f"[PETITIONER] {response.content}",
                               name="PetitionerCounsel")],
        "petitioner_arguments": [response.content],
        "current_phase": "petitioner_questioning",
        "phase_history": ["petitioner_opening"],
        "round_number": 1,
        "active_justice_index": 0,
    }


def justice_question_petitioner(state: SupremeCourtState) -> dict:
    """A single justice asks petitioner counsel a question."""
    case = _case(state)
    idx = state.get("active_justice_index", 0)
    justice = _justice_by_index(state, idx)
    llm = _get_llm()

    # Build context from prior arguments & Q/A
    prev_args = "\n".join(state.get("petitioner_arguments", []))
    prev_qa = "\n".join(
        f"Q ({q['justice']}): {q['question']}\nA: {q.get('answer', 'N/A')}"
        for q in state.get("justice_questions", [])
    )

    system = prompts.ASSOCIATE_JUSTICE_SYSTEM.format(
        justice_name=justice.get("name", "Unknown"),
        leaning=justice.get("leaning", "moderate"),
        specialty_areas=", ".join(justice.get("specialty_areas", ["general law"])),
        temperament=justice.get("temperament", "measured"),
        case_name=case.get("case_name", ""),
        question_presented=case.get("question_presented", ""),
    )
    user = prompts.QUESTIONING_PROMPT.format(
        justice_name=justice.get("name", "Unknown"),
        previous_arguments=prev_args[-2000:],
        previous_qa=prev_qa[-2000:],
    )

    response = llm.invoke([SystemMessage(content=system),
                           HumanMessage(content=user)])
    question_text = response.content
    return {
        "messages": [AIMessage(
            content=f"[JUSTICE {justice.get('name', '').upper()}] {question_text}",
            name=f"Justice_{justice.get('name', 'Unknown').replace(' ', '_')}",
        )],
        "justice_questions": [{"justice": justice.get("name"), "question": question_text,
                               "phase": "petitioner_questioning",
                               "round": state.get("round_number", 1)}],
    }


def petitioner_answer(state: SupremeCourtState) -> dict:
    """Petitioner counsel answers the most recent justice question."""
    case = _case(state)
    llm = _get_llm()
    questions = state.get("justice_questions", [])
    last_q = questions[-1] if questions else {"justice": "Court", "question": "Please elaborate."}

    system = prompts.PETITIONER_COUNSEL_SYSTEM.format(
        case_name=case.get("case_name", ""),
        petitioner_brief=case.get("petitioner_brief", ""),
        lower_court_decision=case.get("lower_court_decision", ""),
        key_precedents=", ".join(case.get("key_precedents", [])),
    )
    user = prompts.ANSWER_QUESTION_PROMPT.format(
        justice_name=last_q["justice"],
        question=last_q["question"],
    )

    response = llm.invoke([SystemMessage(content=system),
                           HumanMessage(content=user)])

    # Advance justice index
    justices = state.get("justices", [])
    next_idx = state.get("active_justice_index", 0) + 1

    update: dict[str, Any] = {
        "messages": [AIMessage(content=f"[PETITIONER] {response.content}",
                               name="PetitionerCounsel")],
        "petitioner_arguments": [response.content],
        "active_justice_index": next_idx,
    }

    # If all justices asked a question in this round, move on
    if next_idx >= len(justices):
        rnd = state.get("round_number", 1)
        max_rnds = state.get("max_questioning_rounds", 3)
        if rnd >= max_rnds:
            update["current_phase"] = "respondent_opening"
            update["phase_history"] = ["petitioner_questioning"]
            update["active_justice_index"] = 0
            update["round_number"] = 1
        else:
            update["round_number"] = rnd + 1
            update["active_justice_index"] = 0

    return update


def respondent_opening(state: SupremeCourtState) -> dict:
    """Respondent counsel delivers opening argument."""
    case = _case(state)
    llm = _get_llm()

    system = prompts.RESPONDENT_COUNSEL_SYSTEM.format(
        case_name=case.get("case_name", ""),
        respondent_brief=case.get("respondent_brief", ""),
        lower_court_decision=case.get("lower_court_decision", ""),
        key_precedents=", ".join(case.get("key_precedents", [])),
    )
    user = prompts.OPENING_ARGUMENT_PROMPT

    response = llm.invoke([SystemMessage(content=system),
                           HumanMessage(content=user)])
    return {
        "messages": [AIMessage(content=f"[RESPONDENT] {response.content}",
                               name="RespondentCounsel")],
        "respondent_arguments": [response.content],
        "current_phase": "respondent_questioning",
        "phase_history": ["respondent_opening"],
        "round_number": 1,
        "active_justice_index": 0,
    }


def justice_question_respondent(state: SupremeCourtState) -> dict:
    """A single justice asks respondent counsel a question."""
    case = _case(state)
    idx = state.get("active_justice_index", 0)
    justice = _justice_by_index(state, idx)
    llm = _get_llm()

    prev_args = "\n".join(state.get("respondent_arguments", []))
    prev_qa = "\n".join(
        f"Q ({q['justice']}): {q['question']}\nA: {q.get('answer', 'N/A')}"
        for q in state.get("justice_questions", [])
        if q.get("phase") == "respondent_questioning"
    )

    system = prompts.ASSOCIATE_JUSTICE_SYSTEM.format(
        justice_name=justice.get("name", "Unknown"),
        leaning=justice.get("leaning", "moderate"),
        specialty_areas=", ".join(justice.get("specialty_areas", ["general law"])),
        temperament=justice.get("temperament", "measured"),
        case_name=case.get("case_name", ""),
        question_presented=case.get("question_presented", ""),
    )
    user = prompts.QUESTIONING_PROMPT.format(
        justice_name=justice.get("name", "Unknown"),
        previous_arguments=prev_args[-2000:],
        previous_qa=prev_qa[-2000:],
    )

    response = llm.invoke([SystemMessage(content=system),
                           HumanMessage(content=user)])
    question_text = response.content
    return {
        "messages": [AIMessage(
            content=f"[JUSTICE {justice.get('name', '').upper()}] {question_text}",
            name=f"Justice_{justice.get('name', 'Unknown').replace(' ', '_')}",
        )],
        "justice_questions": [{"justice": justice.get("name"), "question": question_text,
                               "phase": "respondent_questioning",
                               "round": state.get("round_number", 1)}],
    }


def respondent_answer(state: SupremeCourtState) -> dict:
    """Respondent counsel answers the most recent justice question."""
    case = _case(state)
    llm = _get_llm()
    questions = state.get("justice_questions", [])
    last_q = questions[-1] if questions else {"justice": "Court", "question": "Please elaborate."}

    system = prompts.RESPONDENT_COUNSEL_SYSTEM.format(
        case_name=case.get("case_name", ""),
        respondent_brief=case.get("respondent_brief", ""),
        lower_court_decision=case.get("lower_court_decision", ""),
        key_precedents=", ".join(case.get("key_precedents", [])),
    )
    user = prompts.ANSWER_QUESTION_PROMPT.format(
        justice_name=last_q["justice"],
        question=last_q["question"],
    )

    response = llm.invoke([SystemMessage(content=system),
                           HumanMessage(content=user)])

    justices = state.get("justices", [])
    next_idx = state.get("active_justice_index", 0) + 1

    update: dict[str, Any] = {
        "messages": [AIMessage(content=f"[RESPONDENT] {response.content}",
                               name="RespondentCounsel")],
        "respondent_arguments": [response.content],
        "active_justice_index": next_idx,
    }

    if next_idx >= len(justices):
        rnd = state.get("round_number", 1)
        max_rnds = state.get("max_questioning_rounds", 3)
        if rnd >= max_rnds:
            update["current_phase"] = "petitioner_rebuttal"
            update["phase_history"] = ["respondent_questioning"]
            update["active_justice_index"] = 0
        else:
            update["round_number"] = rnd + 1
            update["active_justice_index"] = 0

    return update


def petitioner_rebuttal(state: SupremeCourtState) -> dict:
    """Petitioner gets a brief rebuttal."""
    case = _case(state)
    llm = _get_llm()

    respondent_args = "\n".join(state.get("respondent_arguments", []))

    system = prompts.PETITIONER_COUNSEL_SYSTEM.format(
        case_name=case.get("case_name", ""),
        petitioner_brief=case.get("petitioner_brief", ""),
        lower_court_decision=case.get("lower_court_decision", ""),
        key_precedents=", ".join(case.get("key_precedents", [])),
    )
    user = (
        f"Deliver a brief rebuttal (roughly 300 words) addressing the "
        f"respondent's key arguments:\n\n{respondent_args[-3000:]}"
    )

    response = llm.invoke([SystemMessage(content=system),
                           HumanMessage(content=user)])
    return {
        "messages": [AIMessage(content=f"[PETITIONER REBUTTAL] {response.content}",
                               name="PetitionerCounsel")],
        "petitioner_arguments": [response.content],
        "current_phase": "justice_deliberation",
        "phase_history": ["petitioner_rebuttal"],
        "active_justice_index": 0,
    }


def justice_deliberate(state: SupremeCourtState) -> dict:
    """A single justice deliberates."""
    case = _case(state)
    idx = state.get("active_justice_index", 0)
    justice = _justice_by_index(state, idx)
    llm = _get_llm()

    pet_summary = "\n".join(state.get("petitioner_arguments", []))[-2000:]
    resp_summary = "\n".join(state.get("respondent_arguments", []))[-2000:]
    key_qs = "\n".join(
        f"- {q['justice']}: {q['question']}" for q in state.get("justice_questions", [])
    )[-2000:]

    system = prompts.ASSOCIATE_JUSTICE_SYSTEM.format(
        justice_name=justice.get("name", "Unknown"),
        leaning=justice.get("leaning", "moderate"),
        specialty_areas=", ".join(justice.get("specialty_areas", ["general law"])),
        temperament=justice.get("temperament", "measured"),
        case_name=case.get("case_name", ""),
        question_presented=case.get("question_presented", ""),
    )
    user = prompts.DELIBERATION_PROMPT.format(
        case_name=case.get("case_name", ""),
        petitioner_summary=pet_summary,
        respondent_summary=resp_summary,
        key_questions=key_qs,
        justice_name=justice.get("name", ""),
    )

    response = llm.invoke([SystemMessage(content=system),
                           HumanMessage(content=user)])

    justices = state.get("justices", [])
    next_idx = idx + 1
    update: dict[str, Any] = {
        "messages": [AIMessage(
            content=f"[DELIBERATION - {justice.get('name', '').upper()}] {response.content}",
            name=f"Justice_{justice.get('name', 'Unknown').replace(' ', '_')}",
        )],
        "justice_deliberations": [{"justice": justice.get("name"),
                                    "deliberation": response.content}],
        "active_justice_index": next_idx,
    }

    if next_idx >= len(justices):
        update["current_phase"] = "voting"
        update["phase_history"] = ["justice_deliberation"]
        update["active_justice_index"] = 0

    return update


def justice_vote(state: SupremeCourtState) -> dict:
    """All justices vote simultaneously."""
    case = _case(state)
    justices = state.get("justices", [])
    llm = _get_llm(temperature=0.2)

    votes: dict[str, str] = {}
    vote_messages = []

    for justice in justices:
        system = prompts.ASSOCIATE_JUSTICE_SYSTEM.format(
            justice_name=justice.get("name", "Unknown"),
            leaning=justice.get("leaning", "moderate"),
            specialty_areas=", ".join(justice.get("specialty_areas", ["general law"])),
            temperament=justice.get("temperament", "measured"),
            case_name=case.get("case_name", ""),
            question_presented=case.get("question_presented", ""),
        )
        user = prompts.VOTING_PROMPT.format(case_name=case.get("case_name", ""))

        response = llm.invoke([SystemMessage(content=system),
                               HumanMessage(content=user)])

        vote_text = response.content.strip()
        if "REVERSE" in vote_text.upper().split("\n")[0]:
            votes[justice.get("name", "Unknown")] = "reverse"
        else:
            votes[justice.get("name", "Unknown")] = "affirm"

        vote_messages.append(AIMessage(
            content=f"[VOTE - {justice.get('name', '').upper()}] {vote_text}",
            name=f"Justice_{justice.get('name', 'Unknown').replace(' ', '_')}",
        ))

    # Tally
    affirm_count = sum(1 for v in votes.values() if v == "affirm")
    reverse_count = sum(1 for v in votes.values() if v == "reverse")
    decision = "AFFIRMED" if affirm_count > reverse_count else "REVERSED"

    return {
        "messages": vote_messages,
        "votes": votes,
        "final_decision": decision,
        "current_phase": "opinion_writing",
        "phase_history": ["voting"],
        "active_justice_index": 0,
    }


def write_majority_opinion(state: SupremeCourtState) -> dict:
    """Chief Justice (or senior justice in majority) writes majority opinion."""
    case = _case(state)
    votes = state.get("votes", {})
    decision = state.get("final_decision", "AFFIRMED")
    majority_vote = "affirm" if decision == "AFFIRMED" else "reverse"

    majority = [n for n, v in votes.items() if v == majority_vote]
    dissenters = [n for n, v in votes.items() if v != majority_vote]
    affirm_count = sum(1 for v in votes.values() if v == "affirm")
    reverse_count = sum(1 for v in votes.values() if v == "reverse")

    llm = _get_llm()
    # Use Chief Justice system prompt for majority opinion
    system = prompts.CHIEF_JUSTICE_SYSTEM.format(
        case_name=case.get("case_name", ""),
        question_presented=case.get("question_presented", ""),
    )
    user = prompts.MAJORITY_OPINION_PROMPT.format(
        case_name=case.get("case_name", ""),
        vote_tally=f"{max(affirm_count, reverse_count)}-{min(affirm_count, reverse_count)}",
        majority_justices=", ".join(majority),
        dissenting_justices=", ".join(dissenters) if dissenters else "None",
    )

    response = llm.invoke([SystemMessage(content=system),
                           HumanMessage(content=user)])
    return {
        "messages": [AIMessage(content=f"[MAJORITY OPINION] {response.content}",
                               name="MajorityOpinion")],
        "majority_opinion": response.content,
        "current_phase": "opinion_writing_dissent",
        "phase_history": ["opinion_writing_majority"],
    }


def write_dissenting_opinions(state: SupremeCourtState) -> dict:
    """Dissenting justices write their opinions."""
    case = _case(state)
    votes = state.get("votes", {})
    decision = state.get("final_decision", "AFFIRMED")
    majority_vote = "affirm" if decision == "AFFIRMED" else "reverse"
    majority_opinion = state.get("majority_opinion", "")

    dissenters = [n for n, v in votes.items() if v != majority_vote]
    justices = state.get("justices", [])
    llm = _get_llm()

    dissent_texts = []
    dissent_messages = []

    for d_name in dissenters:
        j_profile = next((j for j in justices if j.get("name") == d_name),
                         {"name": d_name, "leaning": "moderate",
                          "specialty_areas": ["general law"],
                          "temperament": "measured"})

        system = prompts.ASSOCIATE_JUSTICE_SYSTEM.format(
            justice_name=j_profile.get("name", d_name),
            leaning=j_profile.get("leaning", "moderate"),
            specialty_areas=", ".join(j_profile.get("specialty_areas", ["general law"])),
            temperament=j_profile.get("temperament", "measured"),
            case_name=case.get("case_name", ""),
            question_presented=case.get("question_presented", ""),
        )
        user = prompts.DISSENT_OPINION_PROMPT.format(
            case_name=case.get("case_name", ""),
            your_vote=("affirm" if majority_vote == "reverse" else "reverse"),
            majority_vote=majority_vote,
            majority_summary=majority_opinion[:2000],
        )

        response = llm.invoke([SystemMessage(content=system),
                               HumanMessage(content=user)])
        dissent_texts.append(f"[DISSENT by {d_name}] {response.content}")
        dissent_messages.append(AIMessage(
            content=f"[DISSENT - {d_name.upper()}] {response.content}",
            name=f"Justice_{d_name.replace(' ', '_')}",
        ))

    return {
        "messages": dissent_messages,
        "dissenting_opinions": dissent_texts,
        "current_phase": "case_concluded",
        "phase_history": ["opinion_writing_dissent"],
    }


def court_clerk_conclude(state: SupremeCourtState) -> dict:
    """Clerk announces the final decision."""
    case = _case(state)
    votes = state.get("votes", {})
    decision = state.get("final_decision", "AFFIRMED")
    majority_vote = "affirm" if decision == "AFFIRMED" else "reverse"

    affirm_count = sum(1 for v in votes.values() if v == "affirm")
    reverse_count = sum(1 for v in votes.values() if v == "reverse")
    majority = [n for n, v in votes.items() if v == majority_vote]
    dissenters = [n for n, v in votes.items() if v != majority_vote]

    llm = _get_llm(temperature=0.3)
    system = prompts.COURT_CLERK_SYSTEM.format(
        case_name=case.get("case_name", ""),
        docket_number=case.get("docket_number", "00-000"),
    )
    user = prompts.CASE_CONCLUSION_PROMPT.format(
        case_name=case.get("case_name", ""),
        final_decision=decision,
        vote_tally=f"{max(affirm_count, reverse_count)}-{min(affirm_count, reverse_count)}",
        majority_author=majority[0] if majority else "The Court",
        dissenters=", ".join(dissenters) if dissenters else "None",
    )

    response = llm.invoke([SystemMessage(content=system),
                           HumanMessage(content=user)])
    return {
        "messages": [AIMessage(content=f"[CLERK - FINAL] {response.content}",
                               name="CourtClerk")],
        "current_phase": "case_concluded",
        "phase_history": ["case_concluded"],
    }
