"""
LangGraph workflow – wires all agent nodes into a directed graph
that models the full Supreme Court oral argument procedure.

Graph topology
==============

    ┌─────────────┐
    │  clerk_intro │
    └──────┬──────┘
           ▼
    ┌──────────────────┐
    │ petitioner_open   │
    └──────┬───────────┘
           ▼
    ┌──────────────────────────┐
    │ justice_q_petitioner     │◄──┐
    └──────┬───────────────────┘   │  (loop: next justice
           ▼                       │   or next round)
    ┌──────────────────────────┐   │
    │ petitioner_answer        │───┘
    └──────┬───────────────────┘
           ▼ (all rounds done)
    ┌──────────────────┐
    │ respondent_open   │
    └──────┬───────────┘
           ▼
    ┌──────────────────────────┐
    │ justice_q_respondent     │◄──┐
    └──────┬───────────────────┘   │
           ▼                       │
    ┌──────────────────────────┐   │
    │ respondent_answer        │───┘
    └──────┬───────────────────┘
           ▼ (all rounds done)
    ┌──────────────────────────┐
    │ petitioner_rebuttal      │
    └──────┬───────────────────┘
           ▼
    ┌──────────────────────────┐
    │ justice_deliberate       │◄──┐
    └──────┬───────────────────┘   │  (loop per justice)
           │───────────────────────┘
           ▼ (all justices done)
    ┌──────────────┐
    │ justice_vote  │
    └──────┬───────┘
           ▼
    ┌────────────────────┐
    │ majority_opinion   │
    └──────┬─────────────┘
           ▼
    ┌────────────────────┐
    │ dissenting_opinions│
    └──────┬─────────────┘
           ▼
    ┌──────────────┐
    │ clerk_conclude│
    └──────────────┘
"""

from __future__ import annotations

from langgraph.graph import END, StateGraph

from .agents import (
    court_clerk_conclude,
    court_clerk_introduce,
    justice_deliberate,
    justice_question_petitioner,
    justice_question_respondent,
    justice_vote,
    petitioner_answer,
    petitioner_opening,
    petitioner_rebuttal,
    respondent_answer,
    respondent_opening,
    write_dissenting_opinions,
    write_majority_opinion,
)
from .state import SupremeCourtState


# ---------------------------------------------------------------------------
# Conditional routing helpers
# ---------------------------------------------------------------------------

def _route_after_petitioner_answer(state: SupremeCourtState) -> str:
    """Decide whether to loop back for more questions or advance."""
    if state.get("current_phase") == "respondent_opening":
        return "respondent_open"
    return "justice_q_petitioner"


def _route_after_respondent_answer(state: SupremeCourtState) -> str:
    if state.get("current_phase") == "petitioner_rebuttal":
        return "petitioner_rebuttal"
    return "justice_q_respondent"


def _route_after_deliberation(state: SupremeCourtState) -> str:
    if state.get("current_phase") == "voting":
        return "justice_vote"
    return "justice_deliberate"


# ---------------------------------------------------------------------------
# Graph builder
# ---------------------------------------------------------------------------

def build_graph() -> StateGraph:
    """Construct and compile the Supreme Court debate graph."""

    graph = StateGraph(SupremeCourtState)

    # ── Add nodes ──────────────────────────────────────────────────────
    graph.add_node("clerk_intro", court_clerk_introduce)
    graph.add_node("petitioner_open", petitioner_opening)
    graph.add_node("justice_q_petitioner", justice_question_petitioner)
    graph.add_node("petitioner_answer", petitioner_answer)
    graph.add_node("respondent_open", respondent_opening)
    graph.add_node("justice_q_respondent", justice_question_respondent)
    graph.add_node("respondent_answer", respondent_answer)
    graph.add_node("petitioner_rebuttal", petitioner_rebuttal)
    graph.add_node("justice_deliberate", justice_deliberate)
    graph.add_node("justice_vote", justice_vote)
    graph.add_node("majority_opinion", write_majority_opinion)
    graph.add_node("dissenting_opinions", write_dissenting_opinions)
    graph.add_node("clerk_conclude", court_clerk_conclude)

    # ── Entry point ────────────────────────────────────────────────────
    graph.set_entry_point("clerk_intro")

    # ── Linear edges ───────────────────────────────────────────────────
    graph.add_edge("clerk_intro", "petitioner_open")
    graph.add_edge("petitioner_open", "justice_q_petitioner")
    graph.add_edge("justice_q_petitioner", "petitioner_answer")

    # ── Conditional: loop questions or advance ─────────────────────────
    graph.add_conditional_edges(
        "petitioner_answer",
        _route_after_petitioner_answer,
        {
            "justice_q_petitioner": "justice_q_petitioner",
            "respondent_open": "respondent_open",
        },
    )

    graph.add_edge("respondent_open", "justice_q_respondent")
    graph.add_edge("justice_q_respondent", "respondent_answer")

    graph.add_conditional_edges(
        "respondent_answer",
        _route_after_respondent_answer,
        {
            "justice_q_respondent": "justice_q_respondent",
            "petitioner_rebuttal": "petitioner_rebuttal",
        },
    )

    graph.add_edge("petitioner_rebuttal", "justice_deliberate")

    graph.add_conditional_edges(
        "justice_deliberate",
        _route_after_deliberation,
        {
            "justice_deliberate": "justice_deliberate",
            "justice_vote": "justice_vote",
        },
    )

    graph.add_edge("justice_vote", "majority_opinion")
    graph.add_edge("majority_opinion", "dissenting_opinions")
    graph.add_edge("dissenting_opinions", "clerk_conclude")
    graph.add_edge("clerk_conclude", END)

    return graph.compile()


# Convenience: pre-compiled graph instance
app = build_graph()
