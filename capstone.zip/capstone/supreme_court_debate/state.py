"""
State definitions for the Supreme Court Debate graph.
"""

from __future__ import annotations

import operator
from dataclasses import dataclass, field
from enum import Enum
from typing import Annotated, Any, Optional

from langgraph.graph import MessagesState


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class DebatePhase(str, Enum):
    """Phases of a Supreme Court oral argument session."""
    CASE_INTRODUCTION = "case_introduction"
    PETITIONER_OPENING = "petitioner_opening"
    PETITIONER_QUESTIONING = "petitioner_questioning"
    RESPONDENT_OPENING = "respondent_opening"
    RESPONDENT_QUESTIONING = "respondent_questioning"
    PETITIONER_REBUTTAL = "petitioner_rebuttal"
    JUSTICE_DELIBERATION = "justice_deliberation"
    VOTING = "voting"
    OPINION_WRITING = "opinion_writing"
    CASE_CONCLUDED = "case_concluded"


class JusticeLeaning(str, Enum):
    """Ideological leaning of a justice (affects argumentation style)."""
    CONSERVATIVE = "conservative"
    MODERATE = "moderate"
    LIBERAL = "liberal"


class Vote(str, Enum):
    AFFIRM = "affirm"         # side with respondent / lower court
    REVERSE = "reverse"       # side with petitioner
    ABSTAIN = "abstain"


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class JusticeProfile:
    """Profile for an individual Supreme Court Justice."""
    name: str
    leaning: JusticeLeaning
    specialty_areas: list[str] = field(default_factory=list)
    temperament: str = "measured"          # questioning style hint
    vote: Optional[Vote] = None
    opinion_text: Optional[str] = None


@dataclass
class CaseInfo:
    """Metadata about the case being argued."""
    case_name: str
    docket_number: str
    lower_court_decision: str
    question_presented: str
    petitioner_brief: str
    respondent_brief: str
    key_precedents: list[str] = field(default_factory=list)
    amicus_briefs: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Graph State  (extends LangGraph MessagesState)
# ---------------------------------------------------------------------------

class SupremeCourtState(MessagesState):
    """
    Full state that flows through the LangGraph debate graph.

    Attributes that use ``Annotated[..., operator.add]`` are *append-only*:
    every node that returns a value for that key will **add** to the list
    rather than replace it.
    """

    # ── Case metadata ──────────────────────────────────────────────────
    case_info: Optional[dict] = None           # serialized CaseInfo
    justices: list[dict] = []                  # list of serialized JusticeProfile

    # ── Phase tracking ─────────────────────────────────────────────────
    current_phase: str = DebatePhase.CASE_INTRODUCTION.value
    phase_history: Annotated[list[str], operator.add] = []
    round_number: int = 0
    max_questioning_rounds: int = 3

    # ── Argument logs (append-only) ────────────────────────────────────
    petitioner_arguments: Annotated[list[str], operator.add] = []
    respondent_arguments: Annotated[list[str], operator.add] = []
    justice_questions: Annotated[list[dict], operator.add] = []
    justice_deliberations: Annotated[list[dict], operator.add] = []

    # ── Voting & opinions ──────────────────────────────────────────────
    votes: dict = {}                           # justice_name -> vote
    majority_opinion: str = ""
    dissenting_opinions: Annotated[list[str], operator.add] = []
    concurring_opinions: Annotated[list[str], operator.add] = []
    final_decision: str = ""

    # ── Control flow helpers ───────────────────────────────────────────
    active_justice_index: int = 0
    error: Optional[str] = None
