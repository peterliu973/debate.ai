"""
Supreme Court Multi-Agent Debate System
========================================
A LangGraph-based multi-agent system that simulates a Supreme Court case hearing.

Agents:
- Chief Justice: Presides over oral arguments, manages flow, delivers majority opinion
- Associate Justices (8): Ask questions, deliberate, vote, write concurrences/dissents
- Petitioner Counsel: Argues the case for the petitioner
- Respondent Counsel: Argues the case for the respondent
- Court Clerk: Manages procedure, records, and timing
"""

__version__ = "1.0.0"
