"""
Local runner — test the simulation without deploying to SageMaker.

Usage:
    python run_local.py
    python run_local.py "Your case description here..."
"""

import json
import sys
from src.graph import run_simulation


DEFAULT_CASE = (
    "A state legislature passes a law requiring all social media platforms to verify "
    "the age of users and prohibit anyone under 16 from creating an account. A coalition "
    "of technology companies challenges the law, arguing it violates the First Amendment "
    "rights of minors and imposes an undue burden on interstate commerce. The state "
    "argues the law is a valid exercise of its police power to protect children."
)


def main():
    case = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_CASE

    print("=" * 80)
    print("SCOTUS SIMULATION — LOCAL RUN")
    print("=" * 80)
    print(f"\nCase:\n{case}\n")
    print("Running simulation (this may take a few minutes)...\n")

    result = run_simulation(case)

    print("=" * 80)
    print("OPINION OF THE COURT")
    print("=" * 80)
    print(result.get("opinion", "(no opinion)"))

    print("\n" + "=" * 80)
    print("FULL TRANSCRIPT")
    print("=" * 80)
    for entry in result.get("transcript", []):
        round_label = (
            "Opening" if entry["round"] == 0
            else "Final Opinion" if entry["round"] == -1
            else f"Round {entry['round']}"
        )
        print(f"\n--- {entry['justice']} ({round_label}) ---")
        print(entry["text"])

    with open("simulation_result.json", "w") as f:
        json.dump(result, f, indent=2, default=str)
    print("\n✅ Saved to simulation_result.json")


if __name__ == "__main__":
    main()
