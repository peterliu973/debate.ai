"""
SageMaker-compatible HTTP serving entry-point.

Exposes a FastAPI application that:
  POST /invocations   – run the SCOTUS simulation
  GET  /ping          – health check (required by SageMaker)
"""

import json
import logging
import os
import traceback

from fastapi import FastAPI, Request, Response
import uvicorn

from src.config import get_config
from src.graph import run_simulation

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("scotus-serve")

app = FastAPI(title="SCOTUS Simulation Endpoint")


@app.get("/ping")
def ping():
    """SageMaker health-check endpoint."""
    return Response(content="", status_code=200)


@app.post("/invocations")
async def invocations(request: Request):
    """
    SageMaker inference endpoint.

    Expected JSON body:
    {
        "case_description": "A state law requires all public-school students to ..."
    }

    Returns JSON:
    {
        "opinion": "...",
        "transcript": [...]
    }
    """
    try:
        body = await request.json()
        case_description = body.get("case_description", "")

        if not case_description:
            return Response(
                content=json.dumps({"error": "Missing 'case_description' in request body."}),
                status_code=400,
                media_type="application/json",
            )

        logger.info("Starting simulation for case: %s...", case_description[:120])
        config = get_config()
        result = run_simulation(case_description, config)
        logger.info("Simulation complete.")

        return Response(
            content=json.dumps(result, default=str),
            status_code=200,
            media_type="application/json",
        )

    except Exception as e:
        logger.error("Inference error: %s\n%s", e, traceback.format_exc())
        return Response(
            content=json.dumps({"error": str(e)}),
            status_code=500,
            media_type="application/json",
        )


if __name__ == "__main__":
    port = int(os.environ.get("SAGEMAKER_BIND_TO_PORT", "8080"))
    uvicorn.run(app, host="0.0.0.0", port=port)
