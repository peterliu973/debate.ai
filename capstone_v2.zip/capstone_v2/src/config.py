"""
Configuration module for the SCOTUS Simulation system.
Centralizes all settings, AWS config, and LLM provider configuration.
"""

import os
from pydantic import BaseModel, Field
from dotenv import load_dotenv

load_dotenv()


class AWSConfig(BaseModel):
    """AWS-specific configuration."""
    region: str = Field(default_factory=lambda: os.getenv("AWS_REGION", "us-east-1"))
    s3_bucket: str = Field(default_factory=lambda: os.getenv("S3_BUCKET_NAME", "scotus-simulation-vectorstore"))
    s3_opinions_prefix: str = Field(default_factory=lambda: os.getenv("S3_OPINIONS_PREFIX", "opinions/"))
    sagemaker_role_arn: str = Field(default_factory=lambda: os.getenv("SAGEMAKER_ROLE_ARN", ""))
    sagemaker_endpoint_name: str = Field(default_factory=lambda: os.getenv("SAGEMAKER_ENDPOINT_NAME", "scotus-simulation-endpoint"))
    sagemaker_instance_type: str = Field(default_factory=lambda: os.getenv("SAGEMAKER_INSTANCE_TYPE", "ml.m5.xlarge"))


class LLMConfig(BaseModel):
    """LLM provider configuration — SageMaker AI or HuggingFace."""
    # Provider toggle: "sagemaker" | "huggingface"
    provider: str = Field(
        default_factory=lambda: os.getenv("LLM_PROVIDER", "sagemaker")
    )

    # ── SageMaker settings ──────────────────────────────────────────────
    sagemaker_llm_endpoint: str = Field(
        default_factory=lambda: os.getenv("SAGEMAKER_LLM_ENDPOINT_NAME", "scotus-llm-endpoint")
    )
    sagemaker_embeddings_endpoint: str = Field(
        default_factory=lambda: os.getenv("SAGEMAKER_EMBEDDINGS_ENDPOINT_NAME", "scotus-embeddings-endpoint")
    )
    sagemaker_content_type: str = Field(
        default_factory=lambda: os.getenv("SAGEMAKER_LLM_CONTENT_TYPE", "application/json")
    )

    # ── HuggingFace settings ────────────────────────────────────────────
    hf_api_token: str = Field(
        default_factory=lambda: os.getenv("HF_API_TOKEN", "")
    )
    hf_llm_model: str = Field(
        default_factory=lambda: os.getenv("HF_LLM_MODEL", "mistralai/Mistral-7B-Instruct-v0.3")
    )
    hf_embeddings_model: str = Field(
        default_factory=lambda: os.getenv("HF_EMBEDDINGS_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
    )
    hf_local: bool = Field(
        default_factory=lambda: os.getenv("HF_LOCAL", "false").lower() == "true"
    )

    # ── Shared generation parameters ────────────────────────────────────
    temperature: float = Field(
        default_factory=lambda: float(os.getenv("LLM_TEMPERATURE", "0.7"))
    )
    max_tokens: int = Field(
        default_factory=lambda: int(os.getenv("LLM_MAX_TOKENS", "4096"))
    )


class SimulationConfig(BaseModel):
    """Simulation parameters."""
    num_debate_rounds: int = Field(default=3, description="Number of oral argument / debate rounds")
    max_opinion_references: int = Field(default=5, description="Max past opinions to retrieve per query")


class AppConfig(BaseModel):
    """Root configuration."""
    aws: AWSConfig = Field(default_factory=AWSConfig)
    llm: LLMConfig = Field(default_factory=LLMConfig)
    simulation: SimulationConfig = Field(default_factory=SimulationConfig)


def get_config() -> AppConfig:
    """Return a singleton-style config instance."""
    return AppConfig()
