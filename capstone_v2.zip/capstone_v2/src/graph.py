"""
LangGraph workflow for the SCOTUS Simulation.

Graph topology
==============
                ┌──────────────┐
                │  START        │
                └──────┬───────┘
                       │  case_description
                       ▼
              ┌────────────────┐
              │ chief_open_case│  (frames questions, opens Round 1)
              └───────┬────────┘
                      │
          ┌───────────▼────────────┐
          │  debate_round (loop x3)│
          │  ┌─────────────────┐   │
          │  │ each associate  │   │
          │  │ justice responds│   │
          │  └─────────────────┘   │
          │  chief opens next round│
          └───────────┬────────────┘
                      │  after 3 rounds
                      ▼
             ┌────────────────┐
             │ chief_opinion  │  (final ruling + transcript)
             └───────┬────────┘
                     │
                     ▼
                ┌─────────┐
                │  END    │
                └─────────┘
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, TypedDict, Annotated

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import StateGraph, END

from src.config import AppConfig, get_config
from src.llm import build_llm
from src.justices import (
    JUSTICE_MAP,
    JUSTICE_PROFILES,
    ALL_JUSTICE_IDS,
    CHIEF_JUSTICE_ID,
    ASSOCIATE_JUSTICE_IDS,
    JusticeProfile,
)
from src.prompts import (
    CHIEF_JUSTICE_SYSTEM,
    CHIEF_JUSTICE_OPEN_CASE,
    CHIEF_JUSTICE_OPEN_ROUND,
    CHIEF_JUSTICE_FINAL_OPINION,
    ASSOCIATE_JUSTICE_SYSTEM,
    ASSOCIATE_JUSTICE_RESPOND,
)
from src.vectorstore import (
    build_all_vectorstores,
    build_combined_vectorstore,
    get_justice_retriever,
    get_chief_justice_retriever,
)

logger = logging.getLogger(__name__)

# ── Graph state ─────────────────────────────────────────────────────────────

class SCOTUSState(TypedDict):
    """Shared state flowing through the graph."""
    case_description: str
    current_round: int
    total_rounds: int
    # Each entry: {"round": int, "justice_id": str, "text": str}
    transcript: List[Dict[str, Any]]
    # The prompt the Chief Justice poses for the current round
    round_prompt: str
    # Responses collected in the current round (justice_id → text)
    current_round_responses: Dict[str, str]
    # Final opinion text from the Chief Justice
    final_opinion: str
    # Overall result payload
    result: Dict[str, Any]


# ── Helper: retrieve past opinions ─────────────────────────────────────────

def _retrieve_opinions(retriever, query: str, k: int = 5) -> str:
    """Retrieve and format relevant past opinions."""
    if retriever is None:
        return "(No past opinions available — vector store not loaded.)"
    docs = retriever.invoke(query)
    if not docs:
        return "(No relevant past opinions found.)"
    parts = []
    for i, doc in enumerate(docs, 1):
        meta = doc.metadata
        label = meta.get("case_name", meta.get("s3_key", f"doc-{i}"))
        parts.append(f"[{i}] {label}\n{doc.page_content[:600]}")
    return "\n\n".join(parts)


def _transcript_text(transcript: List[Dict[str, Any]]) -> str:
    """Flatten transcript entries into readable text."""
    lines = []
    for entry in transcript:
        role = JUSTICE_MAP[entry["justice_id"]].name if entry["justice_id"] in JUSTICE_MAP else entry["justice_id"]
        lines.append(f"--- {role} (Round {entry['round']}) ---\n{entry['text']}\n")
    return "\n".join(lines)


def _round_summary(transcript: List[Dict[str, Any]], round_num: int) -> str:
    """Summarize a specific round from the transcript."""
    entries = [e for e in transcript if e["round"] == round_num]
    return _transcript_text(entries) if entries else "(No responses yet.)"


# ── Graph builder ───────────────────────────────────────────────────────────

def build_scotus_graph(config: Optional[AppConfig] = None) -> StateGraph:
    """
    Construct and compile the SCOTUS simulation LangGraph.
    Returns a compiled graph ready for `.invoke()`.
    """
    if config is None:
        config = get_config()

    llm = build_llm(config.llm)
    if config.llm.provider.lower() == "sagemaker":
        llm.region_name = config.aws.region
    num_rounds = config.simulation.num_debate_rounds

    # ── Build vector stores (gracefully degrade if S3 is unavailable) ───
    try:
        justice_stores = build_all_vectorstores(config, ALL_JUSTICE_IDS)
        combined_store = build_combined_vectorstore(config, ALL_JUSTICE_IDS)
    except Exception as e:
        logger.warning("Could not build vector stores from S3: %s. Running without past opinions.", e)
        justice_stores = {}
        combined_store = None

    chief_retriever = get_chief_justice_retriever(combined_store, k=config.simulation.max_opinion_references) if combined_store else None
    justice_retrievers = {
        jid: get_justice_retriever(vs, k=config.simulation.max_opinion_references)
        for jid, vs in justice_stores.items()
    }

    # ── Node functions ──────────────────────────────────────────────────

    def chief_open_case(state: SCOTUSState) -> Dict:
        """Chief Justice frames the case and opens Round 1."""
        profile = JUSTICE_MAP[CHIEF_JUSTICE_ID]
        precedents = _retrieve_opinions(chief_retriever, state["case_description"])

        system_msg = SystemMessage(content=CHIEF_JUSTICE_SYSTEM.format(
            persona_description=profile.persona_description,
            num_rounds=num_rounds,
        ))
        human_msg = HumanMessage(content=CHIEF_JUSTICE_OPEN_CASE.format(
            case_description=state["case_description"],
            precedents=precedents,
        ))

        response = llm.invoke([system_msg, human_msg])
        text = response.content

        return {
            "current_round": 1,
            "total_rounds": num_rounds,
            "round_prompt": text,
            "transcript": [{"round": 0, "justice_id": CHIEF_JUSTICE_ID, "text": text}],
            "current_round_responses": {},
        }

    def associate_justice_debate(state: SCOTUSState) -> Dict:
        """All associate justices respond to the current round prompt."""
        round_num = state["current_round"]
        responses: Dict[str, str] = {}
        new_transcript: List[Dict[str, Any]] = list(state["transcript"])

        for jid in ASSOCIATE_JUSTICE_IDS:
            profile = JUSTICE_MAP[jid]
            retriever = justice_retrievers.get(jid)
            past_opinions = _retrieve_opinions(retriever, state["case_description"])

            # Collect what other justices already said this round
            other_text = "\n".join(
                f"{JUSTICE_MAP[oid].name}: {otxt}" for oid, otxt in responses.items()
            ) or "(You are the first to respond this round.)"

            system_msg = SystemMessage(content=ASSOCIATE_JUSTICE_SYSTEM.format(
                persona_description=profile.persona_description,
                past_opinions=past_opinions,
            ))
            human_msg = HumanMessage(content=ASSOCIATE_JUSTICE_RESPOND.format(
                round_label=f"Round {round_num}",
                round_prompt=state["round_prompt"],
                other_responses=other_text,
                justice_name=profile.name,
            ))

            result = llm.invoke([system_msg, human_msg])
            text = result.content
            responses[jid] = text
            new_transcript.append({"round": round_num, "justice_id": jid, "text": text})

        return {
            "current_round_responses": responses,
            "transcript": new_transcript,
        }

    def chief_open_next_round(state: SCOTUSState) -> Dict:
        """Chief Justice synthesizes the previous round and opens the next."""
        prev_round = state["current_round"]
        next_round = prev_round + 1
        profile = JUSTICE_MAP[CHIEF_JUSTICE_ID]

        summary = _round_summary(state["transcript"], prev_round)

        system_msg = SystemMessage(content=CHIEF_JUSTICE_SYSTEM.format(
            persona_description=profile.persona_description,
            num_rounds=num_rounds,
        ))
        human_msg = HumanMessage(content=CHIEF_JUSTICE_OPEN_ROUND.format(
            prev_round=prev_round,
            round_summary=summary,
            current_round=next_round,
            total_rounds=num_rounds,
        ))

        result = llm.invoke([system_msg, human_msg])
        text = result.content

        new_transcript = list(state["transcript"])
        new_transcript.append({"round": next_round, "justice_id": CHIEF_JUSTICE_ID, "text": text})

        return {
            "current_round": next_round,
            "round_prompt": text,
            "current_round_responses": {},
            "transcript": new_transcript,
        }

    def chief_final_opinion(state: SCOTUSState) -> Dict:
        """Chief Justice delivers the opinion of the Court."""
        profile = JUSTICE_MAP[CHIEF_JUSTICE_ID]
        full_transcript = _transcript_text(state["transcript"])
        precedents = _retrieve_opinions(chief_retriever, state["case_description"])

        system_msg = SystemMessage(content=CHIEF_JUSTICE_SYSTEM.format(
            persona_description=profile.persona_description,
            num_rounds=num_rounds,
        ))
        human_msg = HumanMessage(content=CHIEF_JUSTICE_FINAL_OPINION.format(
            total_rounds=num_rounds,
            full_transcript=full_transcript,
            precedents=precedents,
        ))

        result = llm.invoke([system_msg, human_msg])
        opinion_text = result.content

        new_transcript = list(state["transcript"])
        new_transcript.append({"round": -1, "justice_id": CHIEF_JUSTICE_ID, "text": opinion_text})

        return {
            "final_opinion": opinion_text,
            "transcript": new_transcript,
            "result": {
                "opinion": opinion_text,
                "transcript": [
                    {
                        "round": e["round"],
                        "justice": JUSTICE_MAP.get(e["justice_id"], JusticeProfile(
                            justice_id=e["justice_id"], name=e["justice_id"],
                            title="", ideology="", persona_description=""
                        )).name,
                        "text": e["text"],
                    }
                    for e in new_transcript
                ],
            },
        }

    # ── Routing logic ───────────────────────────────────────────────────

    def should_continue_debate(state: SCOTUSState) -> str:
        """After associate debate, decide: more rounds or final opinion."""
        if state["current_round"] < state["total_rounds"]:
            return "next_round"
        return "final_opinion"

    # ── Assemble the graph ──────────────────────────────────────────────

    graph = StateGraph(SCOTUSState)

    graph.add_node("chief_open_case", chief_open_case)
    graph.add_node("associate_debate", associate_justice_debate)
    graph.add_node("chief_next_round", chief_open_next_round)
    graph.add_node("chief_final_opinion", chief_final_opinion)

    graph.set_entry_point("chief_open_case")
    graph.add_edge("chief_open_case", "associate_debate")
    graph.add_conditional_edges(
        "associate_debate",
        should_continue_debate,
        {
            "next_round": "chief_next_round",
            "final_opinion": "chief_final_opinion",
        },
    )
    graph.add_edge("chief_next_round", "associate_debate")
    graph.add_edge("chief_final_opinion", END)

    return graph.compile()


# ── Public entry point ──────────────────────────────────────────────────────

def run_simulation(case_description: str, config: Optional[AppConfig] = None) -> Dict[str, Any]:
    """
    Run the full SCOTUS simulation end-to-end.

    Args:
        case_description: Plain-text description of the case from the user.
        config: Optional override config.

    Returns:
        Dict with keys "opinion" and "transcript".
    """
    if config is None:
        config = get_config()

    graph = build_scotus_graph(config)

    initial_state: SCOTUSState = {
        "case_description": case_description,
        "current_round": 0,
        "total_rounds": config.simulation.num_debate_rounds,
        "transcript": [],
        "round_prompt": "",
        "current_round_responses": {},
        "final_opinion": "",
        "result": {},
    }

    final_state = graph.invoke(initial_state)
    return final_state["result"]
