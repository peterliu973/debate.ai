"""
S3-backed FAISS vector store for Supreme Court justice opinions.

Architecture:
  - Past opinions are stored as text files in S3 under per-justice prefixes.
  - FAISS indices are built per-justice and cached locally.
  - The Chief Justice retriever queries ALL justice indices.
  - Each Associate Justice retriever queries only their own index.
"""

import json
import os
import tempfile
from typing import Any, Dict, List, Optional

import boto3
import numpy as np
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from langchain_community.vectorstores import FAISS
from langchain_text_splitters import RecursiveCharacterTextSplitter

from src.config import AppConfig


# ═══════════════════════════════════════════════════════════════════════════
# Provider A – SageMaker Embeddings
# ═══════════════════════════════════════════════════════════════════════════

class SageMakerEmbeddings(Embeddings):
    """
    LangChain-compatible embeddings backed by a SageMaker real-time
    inference endpoint (e.g., a HuggingFace sentence-transformers model
    deployed via JumpStart or a custom container).
    """

    def __init__(self, endpoint_name: str, region_name: str = "us-east-1"):
        self.endpoint_name = endpoint_name
        self.region_name = region_name
        self._client = boto3.client("sagemaker-runtime", region_name=region_name)

    def _invoke(self, texts: List[str]) -> List[List[float]]:
        payload = json.dumps({"inputs": texts})
        response = self._client.invoke_endpoint(
            EndpointName=self.endpoint_name,
            ContentType="application/json",
            Accept="application/json",
            Body=payload,
        )
        body = json.loads(response["Body"].read())
        if isinstance(body, list) and len(body) > 0:
            if isinstance(body[0], list):
                return body
            if isinstance(body[0], dict):
                return [item["embedding"] for item in body]
        if isinstance(body, dict) and "embeddings" in body:
            return body["embeddings"]
        raise ValueError(f"Unexpected embedding response shape: {type(body)}")

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        all_embeddings: List[List[float]] = []
        batch_size = 32
        for i in range(0, len(texts), batch_size):
            all_embeddings.extend(self._invoke(texts[i : i + batch_size]))
        return all_embeddings

    def embed_query(self, text: str) -> List[float]:
        return self._invoke([text])[0]


# ═══════════════════════════════════════════════════════════════════════════
# Provider B – HuggingFace Embeddings (API or local)
# ═══════════════════════════════════════════════════════════════════════════

class HuggingFaceEmbeddingsWrapper(Embeddings):
    """
    LangChain-compatible embeddings that call the HuggingFace Inference API
    or load a ``sentence-transformers`` model locally.
    """

    def __init__(
        self,
        model_id: str = "sentence-transformers/all-MiniLM-L6-v2",
        api_token: str = "",
        run_local: bool = False,
    ):
        self.model_id = model_id
        self.api_token = api_token
        self.run_local = run_local
        self._client = None
        self._local_model = None

    # ── lazy init ───────────────────────────────────────────────────────

    def _get_hf_client(self):
        if self._client is None:
            from huggingface_hub import InferenceClient
            self._client = InferenceClient(
                model=self.model_id,
                token=self.api_token or None,
            )
        return self._client

    def _get_local_model(self):
        if self._local_model is None:
            from sentence_transformers import SentenceTransformer
            self._local_model = SentenceTransformer(self.model_id)
        return self._local_model

    # ── embed ───────────────────────────────────────────────────────────

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        if self.run_local:
            model = self._get_local_model()
            vecs = model.encode(texts, show_progress_bar=False)
            return [v.tolist() for v in vecs]
        client = self._get_hf_client()
        return [client.feature_extraction(t).tolist() for t in texts]

    def embed_query(self, text: str) -> List[float]:
        return self.embed_documents([text])[0]


# ═══════════════════════════════════════════════════════════════════════════
# Embeddings factory
# ═══════════════════════════════════════════════════════════════════════════

def _build_embeddings(config: AppConfig) -> Embeddings:
    """Return an embedding model based on the configured provider."""
    provider = config.llm.provider.lower()

    if provider == "sagemaker":
        return SageMakerEmbeddings(
            endpoint_name=config.llm.sagemaker_embeddings_endpoint,
            region_name=config.aws.region,
        )

    if provider == "huggingface":
        return HuggingFaceEmbeddingsWrapper(
            model_id=config.llm.hf_embeddings_model,
            api_token=config.llm.hf_api_token,
            run_local=config.llm.hf_local,
        )

    raise ValueError(
        f"Unsupported LLM_PROVIDER='{config.llm.provider}'. "
        "Choose 'sagemaker' or 'huggingface'."
    )


# ── S3 helpers ──────────────────────────────────────────────────────────────

def _s3_client(config: AppConfig):
    return boto3.client("s3", region_name=config.aws.region)


def _list_opinion_files(config: AppConfig, justice_id: str) -> List[str]:
    """List all opinion text files for a given justice in S3."""
    s3 = _s3_client(config)
    prefix = f"{config.aws.s3_opinions_prefix}{justice_id}/"
    keys: List[str] = []
    paginator = s3.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=config.aws.s3_bucket, Prefix=prefix):
        for obj in page.get("Contents", []):
            if obj["Key"].endswith(".txt") or obj["Key"].endswith(".json"):
                keys.append(obj["Key"])
    return keys


def _load_opinion_documents(config: AppConfig, justice_id: str) -> List[Document]:
    """Download opinion files from S3 and return as LangChain Documents."""
    s3 = _s3_client(config)
    keys = _list_opinion_files(config, justice_id)
    documents: List[Document] = []

    for key in keys:
        response = s3.get_object(Bucket=config.aws.s3_bucket, Key=key)
        body = response["Body"].read().decode("utf-8")

        if key.endswith(".json"):
            data = json.loads(body)
            text = data.get("text", data.get("opinion", body))
            metadata = {
                "justice_id": justice_id,
                "s3_key": key,
                "case_name": data.get("case_name", ""),
                "year": data.get("year", ""),
                "opinion_type": data.get("opinion_type", "majority"),
            }
        else:
            text = body
            metadata = {
                "justice_id": justice_id,
                "s3_key": key,
            }

        documents.append(Document(page_content=text, metadata=metadata))

    return documents


# ── Vector store builder ────────────────────────────────────────────────────

_text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1500,
    chunk_overlap=200,
    separators=["\n\n", "\n", ". ", " ", ""],
)


def build_justice_vectorstore(
    config: AppConfig,
    justice_id: str,
) -> Optional[FAISS]:
    """
    Build a FAISS vector store for a single justice's opinions from S3.
    Returns None if no documents are found.
    """
    docs = _load_opinion_documents(config, justice_id)
    if not docs:
        return None

    chunks = _text_splitter.split_documents(docs)
    embeddings = _build_embeddings(config)
    return FAISS.from_documents(chunks, embeddings)


def build_all_vectorstores(
    config: AppConfig,
    justice_ids: List[str],
) -> Dict[str, FAISS]:
    """Build per-justice vector stores. Returns dict mapping justice_id → FAISS."""
    stores: Dict[str, FAISS] = {}
    for jid in justice_ids:
        vs = build_justice_vectorstore(config, jid)
        if vs is not None:
            stores[jid] = vs
    return stores


def build_combined_vectorstore(
    config: AppConfig,
    justice_ids: List[str],
) -> Optional[FAISS]:
    """
    Build a single merged FAISS index across ALL justices.
    Used by the Chief Justice to query any justice's past opinions.
    """
    all_docs: List[Document] = []
    for jid in justice_ids:
        all_docs.extend(_load_opinion_documents(config, jid))

    if not all_docs:
        return None

    chunks = _text_splitter.split_documents(all_docs)
    embeddings = _build_embeddings(config)
    return FAISS.from_documents(chunks, embeddings)


# ── Retriever wrappers ──────────────────────────────────────────────────────

def get_justice_retriever(vectorstore: FAISS, k: int = 5):
    """Return a retriever scoped to one justice's opinions."""
    return vectorstore.as_retriever(search_kwargs={"k": k})


def get_chief_justice_retriever(vectorstore: FAISS, k: int = 5):
    """Return a retriever over ALL justices' opinions (for the Chief Justice)."""
    return vectorstore.as_retriever(search_kwargs={"k": k})
