"""
Seed the S3 vector store with sample Supreme Court opinion files.

Usage:
    python scripts/seed_opinions.py

This creates sample opinion text files in S3 under the structure:
    s3://<bucket>/opinions/<justice_id>/<case_name>.json

Replace these with real opinion data for production use.
"""

import json
import os
import boto3
from dotenv import load_dotenv

load_dotenv()

BUCKET = os.getenv("S3_BUCKET_NAME", "scotus-simulation-vectorstore")
PREFIX = os.getenv("S3_OPINIONS_PREFIX", "opinions/")
REGION = os.getenv("AWS_REGION", "us-east-1")

# ── Sample opinions (abbreviated for demonstration) ─────────────────────────

SAMPLE_OPINIONS = {
    "roberts": [
        {
            "case_name": "NFIB v. Sebelius (2012)",
            "year": "2012",
            "opinion_type": "majority",
            "text": (
                "The Affordable Care Act's individual mandate cannot be sustained under "
                "the Commerce Clause because the power to regulate commerce presupposes "
                "the existence of commercial activity to be regulated. However, it is "
                "reasonable to construe the mandate as a tax, and Congress does have the "
                "power to tax. The Medicaid expansion, however, is unconstitutionally "
                "coercive when it threatens states with the loss of existing funding."
            ),
        },
    ],
    "thomas": [
        {
            "case_name": "McDonald v. City of Chicago (2010)",
            "year": "2010",
            "opinion_type": "concurrence",
            "text": (
                "The right to keep and bear arms is a privilege of American citizenship "
                "that applies to the States through the Fourteenth Amendment's Privileges "
                "or Immunities Clause, not the Due Process Clause. The Court should "
                "restore the original meaning of the Privileges or Immunities Clause "
                "rather than continuing to rely on substantive due process."
            ),
        },
    ],
    "alito": [
        {
            "case_name": "Dobbs v. Jackson Women's Health Organization (2022)",
            "year": "2022",
            "opinion_type": "majority",
            "text": (
                "The Constitution does not confer a right to abortion. Roe v. Wade and "
                "Planned Parenthood v. Casey are overruled. The authority to regulate "
                "abortion is returned to the people and their elected representatives. "
                "Roe was egregiously wrong from the start; its reasoning was exceptionally "
                "weak, and it has had damaging consequences."
            ),
        },
    ],
    "sotomayor": [
        {
            "case_name": "Utah v. Strieff (2016)",
            "year": "2016",
            "opinion_type": "dissent",
            "text": (
                "The Court's decision creates a perverse incentive for officers to engage "
                "in unconstitutional stops. The exclusionary rule exists to deter police "
                "misconduct, and by allowing evidence obtained after an illegal stop to "
                "be used, we gut the Fourth Amendment's protections for communities of color."
            ),
        },
    ],
    "kagan": [
        {
            "case_name": "West Virginia v. EPA (2022)",
            "year": "2022",
            "opinion_type": "dissent",
            "text": (
                "The majority's 'major questions doctrine' is a made-up doctrine with no "
                "basis in the text of the Constitution or the Administrative Procedure Act. "
                "Congress delegated authority to the EPA to address climate change, and the "
                "Court substitutes its own policy preferences for the expert judgment of "
                "the agency."
            ),
        },
    ],
    "gorsuch": [
        {
            "case_name": "McGirt v. Oklahoma (2020)",
            "year": "2020",
            "opinion_type": "majority",
            "text": (
                "The Creek Nation's reservation was never disestablished by Congress. "
                "On the far end of the Trail of Tears was a promise: a reservation for "
                "the Creek Nation in perpetuity. Because Congress has not said otherwise, "
                "we hold the government to its word."
            ),
        },
    ],
    "kavanaugh": [
        {
            "case_name": "Ramos v. Louisiana (2020)",
            "year": "2020",
            "opinion_type": "concurrence",
            "text": (
                "The Sixth Amendment right to a unanimous jury verdict applies to state "
                "criminal trials through the Fourteenth Amendment. While I agree with "
                "overruling Apodaca, I write separately to emphasize that stare decisis "
                "is not an inexorable command when a prior decision is grievously wrong."
            ),
        },
    ],
    "barrett": [
        {
            "case_name": "TransUnion LLC v. Ramirez (2021)",
            "year": "2021",
            "opinion_type": "concurrence (partial)",
            "text": (
                "Article III standing requires a concrete injury. Not every statutory "
                "violation gives rise to a concrete harm sufficient for standing. I join "
                "the majority but write separately to note the distinction between "
                "injuries at law and injuries in equity."
            ),
        },
    ],
    "jackson": [
        {
            "case_name": "Students for Fair Admissions v. Harvard (2023)",
            "year": "2023",
            "opinion_type": "dissent",
            "text": (
                "The Fourteenth Amendment was enacted to bring formerly enslaved people "
                "into the fabric of American society. Race-conscious admissions programs "
                "further that purpose. The majority's colorblind interpretation ignores "
                "the history and present-day reality of racial inequality in America."
            ),
        },
    ],
}


def seed():
    s3 = boto3.client("s3", region_name=REGION)

    # Ensure bucket exists
    try:
        s3.head_bucket(Bucket=BUCKET)
    except Exception:
        print(f"Creating S3 bucket: {BUCKET}")
        if REGION == "us-east-1":
            s3.create_bucket(Bucket=BUCKET)
        else:
            s3.create_bucket(
                Bucket=BUCKET,
                CreateBucketConfiguration={"LocationConstraint": REGION},
            )

    count = 0
    for justice_id, opinions in SAMPLE_OPINIONS.items():
        for opinion in opinions:
            key = f"{PREFIX}{justice_id}/{opinion['case_name'].replace(' ', '_')}.json"
            body = json.dumps(opinion, indent=2)
            s3.put_object(Bucket=BUCKET, Key=key, Body=body.encode("utf-8"))
            print(f"  Uploaded: s3://{BUCKET}/{key}")
            count += 1

    print(f"\n✅ Seeded {count} sample opinions across {len(SAMPLE_OPINIONS)} justices.")


if __name__ == "__main__":
    seed()
