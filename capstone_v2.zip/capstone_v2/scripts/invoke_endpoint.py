"""
Invoke the deployed SageMaker endpoint with a test case.

Usage:
    python scripts/invoke_endpoint.py "A state passes a law banning ..."
    python scripts/invoke_endpoint.py              # uses a default case
"""

import json
import os
import sys

import boto3
from dotenv import load_dotenv

load_dotenv()

ENDPOINT_NAME = os.getenv("SAGEMAKER_ENDPOINT_NAME", "scotus-simulation-endpoint")
REGION = os.getenv("AWS_REGION", "us-east-1")

DEFAULT_CASE = (
    "A state legislature passes a law requiring all social media platforms to verify "
    "the age of users and prohibit anyone under 16 from creating an account. A coalition "
    "of technology companies challenges the law, arguing it violates the First Amendment "
    "rights of minors and imposes an undue burden on interstate commerce. The state "
    "argues the law is a valid exercise of its police power to protect children."
)


def invoke(case_description: str):
    runtime = boto3.client("sagemaker-runtime", region_name=REGION)
    payload = json.dumps({"case_description": case_description})

    print(f"Invoking endpoint: {ENDPOINT_NAME}")
    print(f"Case: {case_description[:150]}...\n")

    response = runtime.invoke_endpoint(
        EndpointName=ENDPOINT_NAME,
        ContentType="application/json",
        Body=payload,
    )

    result = json.loads(response["Body"].read().decode("utf-8"))

    # Print the opinion
    print("=" * 80)
    print("OPINION OF THE COURT")
    print("=" * 80)
    print(result.get("opinion", "(no opinion returned)"))

    # Print the transcript
    print("\n" + "=" * 80)
    print("FULL TRANSCRIPT")
    print("=" * 80)
    for entry in result.get("transcript", []):
        round_label = f"Round {entry['round']}" if entry["round"] > 0 else (
            "Opening" if entry["round"] == 0 else "Final Opinion"
        )
        print(f"\n--- {entry['justice']} ({round_label}) ---")
        print(entry["text"])

    # Save to file
    with open("simulation_result.json", "w") as f:
        json.dump(result, f, indent=2, default=str)
    print("\n\n✅ Full result saved to simulation_result.json")


if __name__ == "__main__":
    case = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_CASE
    invoke(case)
