"""
Deploy the SCOTUS simulation container to SageMaker as a real-time endpoint.

Usage:
    python scripts/deploy_sagemaker.py

Prerequisites:
    - Docker image built and pushed to ECR
    - .env file populated with AWS credentials and SageMaker role ARN
"""

import os
import sys
import time
import boto3
from dotenv import load_dotenv

load_dotenv()

# ── Configuration ───────────────────────────────────────────────────────────

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
ROLE_ARN = os.getenv("SAGEMAKER_ROLE_ARN")
ENDPOINT_NAME = os.getenv("SAGEMAKER_ENDPOINT_NAME", "scotus-simulation-endpoint")
INSTANCE_TYPE = os.getenv("SAGEMAKER_INSTANCE_TYPE", "ml.m5.xlarge")
ECR_IMAGE_URI = os.getenv("ECR_IMAGE_URI")  # e.g., 123456789.dkr.ecr.us-east-1.amazonaws.com/scotus-sim:latest

if not ROLE_ARN:
    print("ERROR: SAGEMAKER_ROLE_ARN not set in .env")
    sys.exit(1)
if not ECR_IMAGE_URI:
    print("ERROR: ECR_IMAGE_URI not set. Build & push the Docker image first.")
    sys.exit(1)


def deploy():
    sm = boto3.client("sagemaker", region_name=AWS_REGION)
    timestamp = int(time.time())
    model_name = f"scotus-sim-model-{timestamp}"
    config_name = f"scotus-sim-config-{timestamp}"

    # 1. Create Model
    print(f"Creating SageMaker model: {model_name}")
    sm.create_model(
        ModelName=model_name,
        PrimaryContainer={
            "Image": ECR_IMAGE_URI,
            "Environment": {
                "AWS_REGION": AWS_REGION,
                "S3_BUCKET_NAME": os.getenv("S3_BUCKET_NAME", "scotus-simulation-vectorstore"),
                "S3_OPINIONS_PREFIX": os.getenv("S3_OPINIONS_PREFIX", "opinions/"),
                "LLM_PROVIDER": os.getenv("LLM_PROVIDER", "sagemaker"),
                # SageMaker LLM settings
                "SAGEMAKER_LLM_ENDPOINT_NAME": os.getenv("SAGEMAKER_LLM_ENDPOINT_NAME", "scotus-llm-endpoint"),
                "SAGEMAKER_EMBEDDINGS_ENDPOINT_NAME": os.getenv("SAGEMAKER_EMBEDDINGS_ENDPOINT_NAME", "scotus-embeddings-endpoint"),
                "SAGEMAKER_LLM_CONTENT_TYPE": os.getenv("SAGEMAKER_LLM_CONTENT_TYPE", "application/json"),
                # HuggingFace settings (used when LLM_PROVIDER=huggingface)
                "HF_API_TOKEN": os.getenv("HF_API_TOKEN", ""),
                "HF_LLM_MODEL": os.getenv("HF_LLM_MODEL", ""),
                "HF_EMBEDDINGS_MODEL": os.getenv("HF_EMBEDDINGS_MODEL", ""),
                "HF_LOCAL": os.getenv("HF_LOCAL", "false"),
                # Shared
                "LLM_TEMPERATURE": os.getenv("LLM_TEMPERATURE", "0.7"),
                "LLM_MAX_TOKENS": os.getenv("LLM_MAX_TOKENS", "4096"),
            },
        },
        ExecutionRoleArn=ROLE_ARN,
    )

    # 2. Create Endpoint Config
    print(f"Creating endpoint config: {config_name}")
    sm.create_endpoint_config(
        EndpointConfigName=config_name,
        ProductionVariants=[
            {
                "VariantName": "primary",
                "ModelName": model_name,
                "InstanceType": INSTANCE_TYPE,
                "InitialInstanceCount": 1,
                "ContainerStartupHealthCheckTimeoutInSeconds": 600,
            },
        ],
    )

    # 3. Create or Update Endpoint
    try:
        sm.describe_endpoint(EndpointName=ENDPOINT_NAME)
        print(f"Updating existing endpoint: {ENDPOINT_NAME}")
        sm.update_endpoint(
            EndpointName=ENDPOINT_NAME,
            EndpointConfigName=config_name,
        )
    except sm.exceptions.ClientError:
        print(f"Creating new endpoint: {ENDPOINT_NAME}")
        sm.create_endpoint(
            EndpointName=ENDPOINT_NAME,
            EndpointConfigName=config_name,
        )

    # 4. Wait for endpoint to be InService
    print("Waiting for endpoint to be InService (this may take 5-10 minutes)...")
    waiter = sm.get_waiter("endpoint_in_service")
    waiter.wait(
        EndpointName=ENDPOINT_NAME,
        WaiterConfig={"Delay": 30, "MaxAttempts": 40},
    )
    print(f"✅ Endpoint '{ENDPOINT_NAME}' is now InService!")


if __name__ == "__main__":
    deploy()
