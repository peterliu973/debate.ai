"""
Build the Docker image and push it to Amazon ECR.

Usage:
    python scripts/build_and_push.py

Prerequisites:
    - Docker installed and running
    - AWS CLI configured with permissions for ECR
"""

import os
import subprocess
import sys

from dotenv import load_dotenv

load_dotenv()

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
IMAGE_NAME = "scotus-simulation"
IMAGE_TAG = "latest"


def run(cmd: str, check: bool = True):
    print(f"$ {cmd}")
    result = subprocess.run(cmd, shell=True, check=check)
    return result.returncode


def main():
    # 1. Get AWS account ID
    account_id = subprocess.check_output(
        "aws sts get-caller-identity --query Account --output text",
        shell=True,
    ).decode().strip()

    ecr_repo = f"{account_id}.dkr.ecr.{AWS_REGION}.amazonaws.com/{IMAGE_NAME}"
    full_tag = f"{ecr_repo}:{IMAGE_TAG}"

    # 2. Create ECR repository if it doesn't exist
    run(
        f"aws ecr describe-repositories --repository-names {IMAGE_NAME} --region {AWS_REGION}",
        check=False,
    ) or run(
        f"aws ecr create-repository --repository-name {IMAGE_NAME} --region {AWS_REGION}",
    )

    # 3. Authenticate Docker with ECR
    run(
        f"aws ecr get-login-password --region {AWS_REGION} | "
        f"docker login --username AWS --password-stdin {account_id}.dkr.ecr.{AWS_REGION}.amazonaws.com"
    )

    # 4. Build the Docker image
    run(f"docker build -t {IMAGE_NAME}:{IMAGE_TAG} .")

    # 5. Tag and push
    run(f"docker tag {IMAGE_NAME}:{IMAGE_TAG} {full_tag}")
    run(f"docker push {full_tag}")

    print(f"\n✅ Image pushed: {full_tag}")
    print(f"   Set ECR_IMAGE_URI={full_tag} in your .env file, then run deploy_sagemaker.py")


if __name__ == "__main__":
    main()
